"""
FastAPI backend for the Zerodha Kite Connect login flow.

Responsibilities:
  - Accept (api_key, api_secret, request_token) from the frontend.
  - Exchange them for a Kite access token using the official kiteconnect SDK.
  - Persist the access token to a local file ON THE BACKEND ONLY
    (kite_session.json, next to this file). The access token is NEVER
    included in any HTTP response sent to the browser.
  - On startup / on every "am I logged in?" check, try to reuse the saved
    token instead of forcing a fresh login -- this is what lets you restart
    the frontend (or the backend, during --reload) during local development
    without logging in to Kite again, as long as the token hasn't expired
    (Kite access tokens are valid until ~6am IST the next day).
  - Provide a small /api/profile endpoint the dashboard can call: the
    backend uses the stored token to call Kite on the frontend's behalf,
    so the token itself never has to leave the server.
  - Provide /api/signals/scan, a NIFTY 100 SMA-crossover scanner used by
    the dashboard's Signals tab.
  - Provide /api/backtest/run, an options-selling (short strangle / put /
    call) backtester used by the dashboard's Backtest tab. The engine lives
    in backtest_engine.py and the Kite data download + caching in
    backtest_data.py.

Run with:
    uvicorn main:app --reload --port 8000
"""
import io
import json
import os
import time
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import requests
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from kiteconnect import KiteConnect
from kiteconnect.exceptions import KiteException, TokenException

import backtest_engine
from backtest_data import load_nifty_and_vix

# ----------------------------------------------------------------------
# Config
# ----------------------------------------------------------------------
SESSION_FILE = Path(__file__).parent / "kite_session.json"

# Official NIFTY Indices constituent list (used by the Signals scanner).
NIFTY100_CSV_URL = "https://archives.nseindia.com/content/indices/ind_nifty100list.csv"
# Small pause between Kite historical-data calls during a scan so we stay
# comfortably under Kite's rate limit.
SIGNALS_API_CALL_DELAY_SECONDS = 0.35

# Only allow the local Vite dev server to call this API.
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

app = FastAPI(title="Kite Connect Login Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ----------------------------------------------------------------------
# Session storage helpers (server-side only -- never sent to the browser)
# ----------------------------------------------------------------------
def save_session(api_key: str, access_token: str) -> None:
    SESSION_FILE.write_text(
        json.dumps({"api_key": api_key, "access_token": access_token}, indent=2)
    )
    # Best-effort: keep the file readable only by the current user.
    try:
        os.chmod(SESSION_FILE, 0o600)
    except OSError:
        pass


def load_session() -> dict | None:
    if not SESSION_FILE.exists():
        return None
    try:
        return json.loads(SESSION_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def clear_session() -> None:
    if SESSION_FILE.exists():
        SESSION_FILE.unlink()


def get_authenticated_kite() -> KiteConnect:
    """Return a KiteConnect client using the saved session, or raise 401."""
    session = load_session()
    if session is None:
        raise HTTPException(status_code=401, detail="Not logged in.")

    kite = KiteConnect(api_key=session["api_key"])
    kite.set_access_token(session["access_token"])
    return kite


# ----------------------------------------------------------------------
# Request/response models
# ----------------------------------------------------------------------
class LoginRequest(BaseModel):
    api_key: str
    api_secret: str
    request_token: str


class SignalScanRequest(BaseModel):
    short_sma: int = 6
    long_sma: int = 30
    lookback_days: int = 200
    max_stocks: int = 20


class BacktestRequest(BaseModel):
    structure: str = "strangle"          # strangle | short_put | short_call
    delta: float = 0.10                  # target delta of the sold option(s)
    lots: int = 1                        # lots sold per daily entry
    entry_time: str = "10:00"            # HH:MM, 5-minute steps
    stop_multiple: float | None = 2.0    # close everything if loss > N x premium; None = no stop
    strike_step: int = 100               # 50 or 100
    start_date: str | None = None        # YYYY-MM-DD (default: 1 year before end)
    end_date: str | None = None          # YYYY-MM-DD (default: today)
    iv_factor: float = 1.0               # multiplier on India VIX used as implied volatility
    capital: float | None = None         # optional capital for return maths (default: estimated peak margin)


# ----------------------------------------------------------------------
# Signals scanner helpers
# (mirrors the logic in nifty100_sma_scanner.py, wired up as an API call
# instead of a standalone script)
# ----------------------------------------------------------------------
def get_nifty100_list() -> pd.DataFrame:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
        )
    }
    response = requests.get(NIFTY100_CSV_URL, headers=headers, timeout=15)
    response.raise_for_status()

    df = pd.read_csv(io.StringIO(response.text))
    df.columns = [c.strip() for c in df.columns]
    # Expected NSE columns: 'Company Name', 'Industry', 'Symbol', 'Series', 'ISIN Code'
    df = df.rename(columns={"Company Name": "company", "Symbol": "symbol"})
    df = df[["symbol", "company"]].dropna()
    df["symbol"] = df["symbol"].str.strip()
    df["company"] = df["company"].str.strip()
    return df


def map_symbols_to_tokens(kite: KiteConnect, nifty100_df: pd.DataFrame) -> pd.DataFrame:
    instruments = kite.instruments("NSE")
    inst_df = pd.DataFrame(instruments)
    inst_df = inst_df[
        (inst_df["segment"] == "NSE") & (inst_df["instrument_type"] == "EQ")
    ]
    inst_df = inst_df[["tradingsymbol", "instrument_token"]]

    merged = nifty100_df.merge(
        inst_df, left_on="symbol", right_on="tradingsymbol", how="left"
    )
    merged = merged.dropna(subset=["instrument_token"])
    merged["instrument_token"] = merged["instrument_token"].astype(int)
    return merged[["symbol", "company", "instrument_token"]]


def fetch_daily_candles(kite: KiteConnect, instrument_token: int, lookback_days: int) -> pd.DataFrame:
    to_date = datetime.now()
    from_date = to_date - timedelta(days=lookback_days)
    candles = kite.historical_data(instrument_token, from_date, to_date, interval="day")
    df = pd.DataFrame(candles)
    if df.empty:
        return df
    df["date"] = pd.to_datetime(df["date"]).dt.tz_localize(None)
    df = df.sort_values("date").reset_index(drop=True)
    return df


def find_latest_crossover(candles_df: pd.DataFrame, short_sma: int, long_sma: int) -> dict | None:
    df = candles_df.copy()
    df["sma_fast"] = df["close"].rolling(short_sma).mean()
    df["sma_slow"] = df["close"].rolling(long_sma).mean()
    df = df.dropna(subset=["sma_fast", "sma_slow"]).reset_index(drop=True)

    if len(df) < 2:
        return None

    diff = df["sma_fast"] - df["sma_slow"]
    prev_diff = diff.shift(1)

    bullish = (prev_diff < 0) & (diff >= 0)  # fast SMA crosses ABOVE slow SMA
    bearish = (prev_diff > 0) & (diff <= 0)  # fast SMA crosses BELOW slow SMA

    crossover_rows = df[bullish | bearish]
    if crossover_rows.empty:
        return None

    idx = crossover_rows.index[-1]
    row = df.loc[idx]
    return {
        "crossover_date": row["date"].date().isoformat(),
        "signal_type": "Bullish" if bool(bullish.loc[idx]) else "Bearish",
        "close": float(row["close"]),
        "sma_fast": round(float(row["sma_fast"]), 2),
        "sma_slow": round(float(row["sma_slow"]), 2),
    }


# ----------------------------------------------------------------------
# Routes
# ----------------------------------------------------------------------
@app.post("/api/login")
def login(payload: LoginRequest):
    """
    Exchange (api_key, api_secret, request_token) for an access token and
    store it server-side. The access token is deliberately left out of
    this response -- the browser only ever learns whether login succeeded.
    """
    kite = KiteConnect(api_key=payload.api_key)
    try:
        session_data = kite.generate_session(
            payload.request_token, api_secret=payload.api_secret
        )
    except KiteException as e:
        raise HTTPException(status_code=400, detail=f"Kite login failed: {e}")

    access_token = session_data["access_token"]
    save_session(payload.api_key, access_token)

    return {
        "status": "success",
        "user_id": session_data.get("user_id"),
        "user_name": session_data.get("user_name"),
    }


@app.get("/api/session")
def session_status():
    """
    Used by the frontend on startup to decide whether to show the login
    page or go straight to the dashboard. Confirms the saved token still
    works by making one lightweight call to Kite; if it's expired/invalid,
    the stale session file is cleared automatically.
    """
    session = load_session()
    if session is None:
        return {"logged_in": False}

    kite = KiteConnect(api_key=session["api_key"])
    kite.set_access_token(session["access_token"])
    try:
        profile = kite.profile()
    except KiteException:
        clear_session()
        return {"logged_in": False}

    return {"logged_in": True, "user_name": profile.get("user_name")}


@app.get("/api/profile")
def profile():
    """Dashboard data -- fetched backend-side using the stored token."""
    kite = get_authenticated_kite()
    try:
        return kite.profile()
    except KiteException as e:
        clear_session()
        raise HTTPException(status_code=401, detail=f"Session expired: {e}")


@app.get("/api/margins")
def margins():
    """A second example dashboard call -- account fund/margin summary."""
    kite = get_authenticated_kite()
    try:
        return kite.margins()
    except KiteException as e:
        clear_session()
        raise HTTPException(status_code=401, detail=f"Session expired: {e}")


@app.post("/api/signals/scan")
def scan_signals(req: SignalScanRequest):
    """
    NIFTY 100 SMA crossover scanner, used by the Signals tab.

    Downloads the official NIFTY 100 constituent list, maps each symbol to
    its Kite instrument token, pulls daily candles for each (up to
    max_stocks), computes a short/long SMA pair, and returns the most
    recent bullish/bearish crossover per stock -- ranked most recent first.

    This can take a while for a large max_stocks value (one Kite API call
    per stock, with a small delay between each), so the frontend should
    show a loading state while waiting for the response.
    """
    if req.short_sma < 1 or req.long_sma <= req.short_sma:
        raise HTTPException(
            status_code=400,
            detail="Long SMA must be greater than Short SMA, and both must be positive.",
        )
    if req.lookback_days < req.long_sma + 5:
        raise HTTPException(
            status_code=400,
            detail=f"Lookback Days should be at least {req.long_sma + 5} to compute a {req.long_sma}-day SMA.",
        )
    if not (1 <= req.max_stocks <= 100):
        raise HTTPException(status_code=400, detail="Max Stocks must be between 1 and 100.")

    kite = get_authenticated_kite()

    try:
        nifty100_df = get_nifty100_list()
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"Could not download the NIFTY 100 list from NSE: {e}")

    mapped_df = map_symbols_to_tokens(kite, nifty100_df)
    mapped_df = mapped_df.head(req.max_stocks)

    results = []
    for row in mapped_df.itertuples(index=False):
        try:
            candles = fetch_daily_candles(kite, row.instrument_token, req.lookback_days)
            crossover = find_latest_crossover(candles, req.short_sma, req.long_sma)
            if crossover is not None:
                results.append({"symbol": row.symbol, "company": row.company, **crossover})
        except KiteException:
            pass  # skip a symbol Kite errors on rather than failing the whole scan
        time.sleep(SIGNALS_API_CALL_DELAY_SECONDS)

    results.sort(key=lambda r: r["crossover_date"], reverse=True)
    for i, r in enumerate(results, start=1):
        r["rank"] = i

    return {
        "signals": results,
        "scanned": len(mapped_df),
        "with_signal": len(results),
        "short_sma": req.short_sma,
        "long_sma": req.long_sma,
    }


@app.post("/api/backtest/run")
def run_backtest(req: BacktestRequest):
    """
    Options-selling backtest used by the Backtest tab.

    Downloads (and caches) 5-minute NIFTY 50 and India VIX candles from
    Kite, then runs backtest_engine.run_backtest on them: every trading day
    at `entry_time` sell `lots` lot(s) of the next monthly expiry at the
    strike(s) closest to `delta`, hold to expiry, and close everything if
    the open book's loss exceeds `stop_multiple` x the premium collected.

    The first run for a long period downloads a lot of candles (several
    Kite calls) and can take a minute; later runs reuse the local cache.
    """
    try:
        params = backtest_engine.normalize_params(req.model_dump())
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    kite = get_authenticated_kite()
    try:
        nifty, vix = load_nifty_and_vix(kite, params["start_date"], params["end_date"])
    except TokenException as e:
        clear_session()
        raise HTTPException(status_code=401, detail=f"Session expired: {e}")
    except KiteException as e:
        raise HTTPException(status_code=502, detail=f"Kite could not provide the market data: {e}")

    try:
        return backtest_engine.run_backtest(nifty, vix, params)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/logout")
def logout():
    clear_session()
    return {"status": "logged_out"}
