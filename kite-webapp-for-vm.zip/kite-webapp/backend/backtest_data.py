"""
Market-data loader for the Backtest tab.

Pulls 5-minute NIFTY 50 and India VIX candles from Kite (in chunks that
respect Kite's per-request limit) and caches COMPLETED days on disk so the
next backtest only downloads what is new. Today's (still-forming) candles
are always fetched fresh and never cached.
"""
from __future__ import annotations

import json
import os
import time
from datetime import date, datetime, timedelta
from pathlib import Path

from kiteconnect import KiteConnect

NIFTY_TOKEN = 256265      # NSE: NIFTY 50 (index)
VIX_TOKEN = 264969        # NSE: INDIA VIX (index)
INTERVAL = "5minute"
CHUNK_DAYS = 90           # Kite allows up to 100 days per 5-minute request
CALL_DELAY_SECONDS = 0.4  # stay well under Kite's historical-data rate limit

CACHE_DIR = Path(__file__).parent / "data_cache"


def _cache_path(name: str) -> Path:
    return CACHE_DIR / f"{name}_{INTERVAL}.json"


def _load_cache(name: str) -> dict:
    path = _cache_path(name)
    if path.exists():
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {"covered_from": None, "covered_to": None, "bars": []}


def _save_cache(name: str, cache: dict) -> None:
    CACHE_DIR.mkdir(exist_ok=True)
    tmp = _cache_path(name).with_suffix(".tmp")
    tmp.write_text(json.dumps(cache))
    os.replace(tmp, _cache_path(name))


def _fetch_range(kite: KiteConnect, token: int, start: date, end: date) -> list[dict]:
    """Download candles for [start, end] (inclusive) in <=90-day chunks."""
    out = []
    cur = start
    while cur <= end:
        chunk_end = min(cur + timedelta(days=CHUNK_DAYS - 1), end)
        from_dt = datetime.combine(cur, datetime.min.time())
        to_dt = datetime.combine(chunk_end, datetime.max.time().replace(microsecond=0))
        for attempt in range(3):
            try:
                rows = kite.historical_data(token, from_dt, to_dt, interval=INTERVAL)
                break
            except Exception as e:  # network hiccups / rate limit -> brief retry, otherwise surface
                name = type(e).__name__
                if attempt < 2 and name in ("NetworkException", "GeneralException", "TimeoutException", "ConnectionError"):
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise
        for r in rows:
            d = r["date"]
            out.append({
                "date": d.replace(tzinfo=None).isoformat(),
                "open": float(r["open"]), "high": float(r["high"]),
                "low": float(r["low"]), "close": float(r["close"]),
            })
        cur = chunk_end + timedelta(days=1)
        time.sleep(CALL_DELAY_SECONDS)
    return out


def get_bars(kite: KiteConnect, token: int, name: str, start: date, end: date) -> list[dict]:
    """Candles for [start, end], using and extending the on-disk cache."""
    today = date.today()
    complete_end = min(end, today - timedelta(days=1))     # days that are finished
    cache = _load_cache(name)
    cf = date.fromisoformat(cache["covered_from"]) if cache["covered_from"] else None
    ct = date.fromisoformat(cache["covered_to"]) if cache["covered_to"] else None

    bars = {b["date"]: b for b in cache["bars"]}
    if complete_end >= start:
        if cf is None:
            new = _fetch_range(kite, token, start, complete_end)
            cf, ct = start, complete_end
        else:
            new = []
            if start < cf:
                new += _fetch_range(kite, token, start, cf - timedelta(days=1))
                cf = start
            if complete_end > ct:
                new += _fetch_range(kite, token, ct + timedelta(days=1), complete_end)
                ct = complete_end
        for b in new:
            bars[b["date"]] = b
        cache = {"covered_from": cf.isoformat(), "covered_to": ct.isoformat(),
                 "bars": [bars[k] for k in sorted(bars)]}
        _save_cache(name, cache)

    result = [b for k, b in sorted(bars.items())
              if start.isoformat() <= k[:10] <= min(end, today).isoformat()]

    # today's candles (market may still be open) -- fetched fresh, never cached
    if end >= today and start <= today:
        result += _fetch_range(kite, token, today, today)
    return result


def load_nifty_and_vix(kite: KiteConnect, start: date, end: date):
    nifty = get_bars(kite, NIFTY_TOKEN, "nifty50", start, end)
    vix = get_bars(kite, VIX_TOKEN, "indiavix", start, end)
    return nifty, vix
