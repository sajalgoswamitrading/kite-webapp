"""
Options-selling backtest engine (NIFTY monthly options).

What it simulates
-----------------
Every trading day at a chosen time, sell 1+ lots of NIFTY options on the
NEXT monthly expiry, picking the strike(s) whose delta is closest to (but
not above) a target delta:

  * "strangle"   - sell an out-of-the-money call AND put
  * "short_put"  - sell an out-of-the-money put only
  * "short_call" - sell an out-of-the-money call only

Positions are held to expiry. If the open book's loss exceeds
`stop_multiple` x the premium collected on that book, everything is closed
and the strategy starts fresh with an empty book on the next trading day.

Important: real prices of expired options are not available from Kite, so
option prices are MODELLED with Black-Scholes using the real NIFTY spot and
the real India VIX (used as implied volatility). Margin is ESTIMATED with a
SPAN-style scenario model. Both are simplifications -- see ASSUMPTIONS.

This module is pure Python (no Kite / web code) so it can be tested on
its own: run_backtest(nifty_bars, vix_bars, params) -> dict.
"""
from __future__ import annotations

import datetime as dt
import math
from collections import OrderedDict, defaultdict
from statistics import NormalDist

# ----------------------------------------------------------------------
# Constants / market rules
# ----------------------------------------------------------------------
# NIFTY lot size 75 became effective 2024-11-20; the exchange rules,
# STT and exchange-fee schedule below are modelled from that date on.
MIN_START = dt.date(2024, 11, 20)
RISK_FREE = 0.065

STRUCTURES = ("strangle", "short_put", "short_call")

# Bars whose open-time is in this set get a margin snapshot (plus one right
# after every entry).
_SNAP_TIMES = {dt.time(9, 15), dt.time(10, 0), dt.time(11, 0), dt.time(12, 0),
               dt.time(13, 0), dt.time(14, 0), dt.time(15, 0)}

SPAN_PRICE_RANGE = 0.085   # SPAN-style price scan range (+/- % of spot)
SPAN_VOL_RANGE = 0.04      # SPAN-style volatility scan range (+/- vol points)
EXPOSURE_MARGIN = 0.02     # exposure margin on short index options
EXPIRY_DAY_EXTRA = 0.02    # extra exposure margin on expiring legs on expiry day

ASSUMPTIONS = [
    "Option prices are modelled (Black-Scholes) from real NIFTY spot and India VIX candles - "
    "real prices of expired options are not available from Kite.",
    "India VIX is used as the implied volatility for every strike (no volatility skew, no bid-ask spread, no slippage).",
    "Positions are held to expiry (or until the stop-loss closes the whole book). Expiry settles at the NIFTY close.",
    "Stop-loss is checked at the close of every 5-minute candle on the whole open book.",
    "Margin is an estimate from a SPAN-style model (+/-8.5% price scan, +/-4 vol-point scan, 2% exposure margin, "
    "extra 2% on expiring options on expiry day). It is not Zerodha's exact figure.",
    "Costs use Zerodha's F&O options charges: Rs 20 per order, exchange fees, SEBI fees, STT on sells "
    "(0.10%, 0.15% from 1 Apr 2026), stamp duty on buys and 18% GST.",
    "Lot size: 75 until 29 Dec 2025, 65 from 30 Dec 2025. Monthly expiry: last Thursday until Aug 2025, last Tuesday after.",
]


# ----------------------------------------------------------------------
# Parameter handling
# ----------------------------------------------------------------------
def _parse_date(v, name):
    if isinstance(v, dt.date):
        return v
    try:
        return dt.date.fromisoformat(str(v)[:10])
    except ValueError:
        raise ValueError(f"{name} must be a date like 2025-09-23.")


def normalize_params(raw: dict, today: dt.date | None = None) -> dict:
    """Validate user input and fill defaults. Raises ValueError with a friendly message."""
    today = today or dt.date.today()
    p = {}

    structure = str(raw.get("structure", "strangle"))
    if structure not in STRUCTURES:
        raise ValueError("Strategy must be one of: strangle, short_put, short_call.")
    p["structure"] = structure

    try:
        delta = float(raw.get("delta", 0.10))
    except (TypeError, ValueError):
        raise ValueError("Delta must be a number, e.g. 0.10.")
    if not (0.02 <= delta <= 0.45):
        raise ValueError("Delta must be between 0.02 and 0.45 (e.g. 0.10 = a 10-delta option).")
    p["delta"] = round(delta, 4)

    try:
        lots = int(raw.get("lots", 1))
    except (TypeError, ValueError):
        raise ValueError("Lots per entry must be a whole number.")
    if not (1 <= lots <= 100):
        raise ValueError("Lots per entry must be between 1 and 100.")
    p["lots"] = lots

    et = str(raw.get("entry_time", "10:00"))
    try:
        h, m = et.split(":")[:2]
        entry_time = dt.time(int(h), int(m))
    except (ValueError, TypeError):
        raise ValueError("Entry time must look like 10:00.")
    if not (dt.time(9, 20) <= entry_time <= dt.time(15, 0)) or entry_time.minute % 5:
        raise ValueError("Entry time must be between 09:20 and 15:00, in 5-minute steps.")
    p["entry_time"] = entry_time.strftime("%H:%M")

    sm = raw.get("stop_multiple", 2.0)
    if sm in (None, "", 0, "0"):
        p["stop_multiple"] = None
    else:
        try:
            sm = float(sm)
        except (TypeError, ValueError):
            raise ValueError("Stop-loss multiple must be a number, e.g. 2 (or leave it off).")
        if not (0.5 <= sm <= 20):
            raise ValueError("Stop-loss multiple must be between 0.5 and 20 times the premium collected.")
        p["stop_multiple"] = sm

    try:
        step = int(raw.get("strike_step", 100))
    except (TypeError, ValueError):
        raise ValueError("Strike step must be 50 or 100.")
    if step not in (50, 100):
        raise ValueError("Strike step must be 50 or 100.")
    p["strike_step"] = step

    try:
        ivf = float(raw.get("iv_factor", 1.0))
    except (TypeError, ValueError):
        raise ValueError("IV adjustment must be a number, e.g. 1.0.")
    if not (0.5 <= ivf <= 2.0):
        raise ValueError("IV adjustment must be between 0.5 and 2.0.")
    p["iv_factor"] = ivf

    cap = raw.get("capital")
    if cap in (None, "", 0, "0"):
        p["capital"] = None
    else:
        try:
            cap = float(cap)
        except (TypeError, ValueError):
            raise ValueError("Capital must be a number in rupees.")
        if cap <= 0:
            raise ValueError("Capital must be greater than zero.")
        p["capital"] = cap

    end = _parse_date(raw.get("end_date") or today, "End date")
    start = _parse_date(raw.get("start_date") or (end - dt.timedelta(days=365)), "Start date")
    warnings = []
    if start < MIN_START:
        warnings.append(
            f"Start date moved to {MIN_START.isoformat()} - the earliest date this model supports "
            "(NIFTY lot size 75 and the current exchange fee schedule apply from then)."
        )
        start = MIN_START
    if end > today:
        end = today
    if (end - start).days < 30:
        raise ValueError("Please choose a period of at least 30 days.")
    p["start_date"] = start
    p["end_date"] = end
    p["_warnings"] = warnings
    return p


# ----------------------------------------------------------------------
# Option maths
# ----------------------------------------------------------------------
_ND = NormalDist()


def _cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def bs_price(S, K, T, sig, is_call):
    if T <= 0:
        return max(S - K, 0.0) if is_call else max(K - S, 0.0)
    sq = sig * math.sqrt(T)
    d1 = (math.log(S / K) + (RISK_FREE + 0.5 * sig * sig) * T) / sq
    d2 = d1 - sq
    if is_call:
        return S * _cdf(d1) - K * math.exp(-RISK_FREE * T) * _cdf(d2)
    return K * math.exp(-RISK_FREE * T) * _cdf(-d2) - S * _cdf(-d1)


def bs_delta(S, K, T, sig, is_call):
    sq = sig * math.sqrt(T)
    d1 = (math.log(S / K) + (RISK_FREE + 0.5 * sig * sig) * T) / sq
    return _cdf(d1) if is_call else _cdf(d1) - 1.0


def pick_strikes(S, T, sig, target_delta, step):
    """
    Strikes on the `step` grid whose |delta| is closest to target_delta
    WITHOUT going above it (calls: first strike at/above the exact-delta
    strike; puts: last strike at/below it).
    """
    z = _ND.inv_cdf(1.0 - target_delta)          # d1 magnitude for the target delta
    sq = sig * math.sqrt(T)
    drift = (RISK_FREE + 0.5 * sig * sig) * T
    k_call = S * math.exp(z * sq + drift)
    k_put = S * math.exp(-z * sq + drift)
    kc = math.ceil(k_call / step) * step
    kp = math.floor(k_put / step) * step
    while bs_delta(S, kc, T, sig, True) > target_delta + 1e-9:
        kc += step
    while abs(bs_delta(S, kp, T, sig, False)) > target_delta + 1e-9:
        kp -= step
    return kc, kp


def _years_to_expiry(now: dt.datetime, expiry: dt.date) -> float:
    end = dt.datetime.combine(expiry, dt.time(15, 30))
    return (end - now).total_seconds() / (365.25 * 86400.0)


# ----------------------------------------------------------------------
# Market rules
# ----------------------------------------------------------------------
def lot_size(d: dt.date) -> int:
    return 75 if d <= dt.date(2025, 12, 29) else 65


def _last_weekday_of_month(y, m, weekday):
    d = dt.date(y + (m == 12), (m % 12) + 1, 1) - dt.timedelta(days=1)
    while d.weekday() != weekday:
        d -= dt.timedelta(days=1)
    return d


def monthly_expiries(first_day: dt.date, last_day: dt.date, trading_days: set, last_data_day: dt.date):
    """Monthly NIFTY expiry dates covering [first_day, last_day + ~4 months]."""
    out = []
    y, m = first_day.year, first_day.month
    stop = last_day + dt.timedelta(days=125)
    while (y, m) <= (stop.year, stop.month):
        weekday = 3 if (y, m) <= (2025, 8) else 1  # Thursday until Aug 2025, Tuesday after
        e = _last_weekday_of_month(y, m, weekday)
        if e <= last_data_day:
            while e not in trading_days:   # holiday -> previous trading day
                e -= dt.timedelta(days=1)
        out.append(e)
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def _charges(value, side, d, orders):
    brokerage = 20.0 * orders
    exchange = value * 0.0003553
    sebi = value * 1e-6
    stt = value * (0.001 if d < dt.date(2026, 4, 1) else 0.0015) if side == "sell" else 0.0
    stamp = value * 0.00003 if side == "buy" else 0.0
    gst = 0.18 * (brokerage + exchange + sebi)
    return brokerage + exchange + sebi + stt + stamp + gst


# ----------------------------------------------------------------------
# Margin estimate (SPAN-style)
# ----------------------------------------------------------------------
def _book_margin(positions, S, sig, now, d):
    """Return (span_risk, exposure_margin) in rupees for the open book."""
    if not positions:
        return 0.0, 0.0
    # collapse identical contracts
    contracts = defaultdict(float)
    for p in positions:
        contracts[(p["expiry"], p["strike"], p["is_call"])] += p["qty"]
    items = []
    for (expiry, strike, is_call), qty in contracts.items():
        T = max(_years_to_expiry(now, expiry), 1e-7)
        items.append((strike, T, is_call, qty, bs_price(S, strike, T, sig, is_call), expiry))

    scenarios = []
    for f in (-1, -2 / 3, -1 / 3, 0, 1 / 3, 2 / 3, 1):
        for dv in (-SPAN_VOL_RANGE, SPAN_VOL_RANGE):
            scenarios.append((f * SPAN_PRICE_RANGE, dv, 1.0))
    scenarios += [(-2 * SPAN_PRICE_RANGE, 0.0, 0.35), (2 * SPAN_PRICE_RANGE, 0.0, 0.35)]

    worst = 0.0
    for mv, dv, wt in scenarios:
        S2 = S * (1.0 + mv)
        sg = max(sig + dv, 0.03)
        loss = 0.0
        for strike, T, is_call, qty, base, _e in items:
            loss += (bs_price(S2, strike, T, sg, is_call) - base) * qty
        worst = max(worst, loss * wt)

    exposure = 0.0
    for strike, T, is_call, qty, base, expiry in items:
        pct = EXPOSURE_MARGIN + (EXPIRY_DAY_EXTRA if expiry == d else 0.0)
        exposure += S * qty * pct
    return worst, exposure


# ----------------------------------------------------------------------
# Data helpers
# ----------------------------------------------------------------------
def _parse_ts(s) -> dt.datetime:
    if isinstance(s, dt.datetime):
        return s.replace(tzinfo=None)
    return dt.datetime.fromisoformat(str(s)).replace(tzinfo=None)


def _group_days(nifty_bars, vix_bars):
    vix_by_ts = {_parse_ts(b["date"]): b for b in vix_bars}
    days = OrderedDict()
    for b in sorted(nifty_bars, key=lambda x: _parse_ts(x["date"])):
        t = _parse_ts(b["date"])
        v = vix_by_ts.get(t)
        if v is None or not v.get("close") or v["close"] <= 0:
            continue    # need a VIX value for the same bar
        days.setdefault(t.date(), []).append((t, b, v))
    return days


# ----------------------------------------------------------------------
# Main entry point
# ----------------------------------------------------------------------
def run_backtest(nifty_bars, vix_bars, params: dict) -> dict:
    p = params
    warnings = list(p.get("_warnings", []))
    days = _group_days(nifty_bars, vix_bars)
    if not days:
        raise ValueError("No market data was available for the selected period.")
    last_data_day = max(days)
    # A "full" trading day has (nearly) all 75 five-minute candles; the latest
    # day may be partial if we are running during market hours.
    trading_days = [d for d, bars in days.items() if len(bars) >= 70 or d == last_data_day]
    tdset = set(trading_days)

    start = max(p["start_date"], trading_days[0])
    end = min(p["end_date"], last_data_day)
    run_days = [d for d in trading_days if start <= d <= end]
    if len(run_days) < 15:
        raise ValueError("Not enough trading days with data in the selected period.")
    if start > p["start_date"] + dt.timedelta(days=7):
        warnings.append(f"Market data only starts on {start.isoformat()}, so the test begins then.")

    expiries = monthly_expiries(run_days[0], run_days[-1], tdset, last_data_day)

    def next_expiry(d):
        for e in expiries:
            if e > d:
                return e
        raise ValueError("Could not determine the next monthly expiry.")

    entry_time = dt.time.fromisoformat(p["entry_time"])
    delta_target = p["delta"]
    structure = p["structure"]
    stop_mult = p["stop_multiple"]
    step = p["strike_step"]
    ivf = p["iv_factor"]
    lots = p["lots"]

    positions = []
    entries = []
    stops = []
    equity_bars = []
    margin_snaps = []
    realized_net = 0.0
    cost_total = 0.0
    resume_date = run_days[0]
    stopped_today = None
    entry_id = 0

    def mark(pos, S, sig, now):
        return bs_price(S, pos["strike"], _years_to_expiry(now, pos["expiry"]), sig, pos["is_call"])

    for d in run_days:
        bars = days[d]
        for i, (t, r, v) in enumerate(bars):
            just_entered = False
            # ---- entry ----
            if t.time() == entry_time and d >= resume_date and stopped_today != d:
                S = r["open"]
                sig = v["open"] / 100.0 * ivf
                if S > 0 and sig > 0:
                    e = next_expiry(d)
                    T = _years_to_expiry(t, e)
                    kc, kp = pick_strikes(S, T, sig, delta_target, step)
                    qty = lot_size(d) * lots
                    legs = []
                    if structure in ("strangle", "short_call"):
                        legs.append((True, kc))
                    if structure in ("strangle", "short_put"):
                        legs.append((False, kp))
                    entry_id += 1
                    row = dict(id=entry_id, date=d, time=t, expiry=e, spot=S, vix=v["open"], qty=qty,
                               call_strike=kc if structure != "short_put" else None,
                               put_strike=kp if structure != "short_call" else None,
                               call_delta=None, put_delta=None, call_prem=None, put_prem=None,
                               entry_cost=0.0, exit_cost=0.0, gross=0.0,
                               exit_time=None, exit_reason=None, open=True)
                    for is_call, K in legs:
                        pr = bs_price(S, K, T, sig, is_call)
                        dl = bs_delta(S, K, T, sig, is_call)
                        c = _charges(pr * qty, "sell", d, 1)
                        row["entry_cost"] += c
                        cost_total += c
                        realized_net -= c
                        if is_call:
                            row["call_prem"], row["call_delta"] = pr, dl
                        else:
                            row["put_prem"], row["put_delta"] = pr, dl
                        positions.append(dict(row=row, expiry=e, strike=K, is_call=is_call, entry=pr, qty=qty))
                    entries.append(row)
                    just_entered = True

            # ---- margin snapshot ----
            if positions and (just_entered or t.time() in _SNAP_TIMES):
                span, expo = _book_margin(positions, r["open"], v["open"] / 100.0 * ivf, t, d)
                margin_snaps.append((t, span + expo, d))

            # ---- mark to market at bar close ----
            now = t + dt.timedelta(minutes=5)
            S = r["close"]
            sig = v["close"] / 100.0 * ivf
            is_settlement_bar = (t.time() == dt.time(15, 25))
            if not positions:
                equity_bars.append((now, realized_net))
                continue

            marks = []
            for pos in positions:
                if pos["expiry"] == d and is_settlement_bar:
                    marks.append(bs_price(S, pos["strike"], 0.0, sig, pos["is_call"]))
                else:
                    marks.append(mark(pos, S, sig, now))
            premium = sum(pos["entry"] * pos["qty"] for pos in positions)
            unreal = sum((pos["entry"] - m) * pos["qty"] for pos, m in zip(positions, marks))
            loss = -unreal

            if stop_mult is not None and loss > stop_mult * premium:
                per_contract = defaultdict(float)
                for pos, m in zip(positions, marks):
                    if not (pos["expiry"] == d and is_settlement_bar):
                        per_contract[(pos["expiry"], pos["strike"], pos["is_call"])] += m * pos["qty"]
                exit_cost = sum(_charges(val, "buy", d, 1) for val in per_contract.values())
                cost_total += exit_cost
                realized_net -= exit_cost
                gross_book = 0.0
                tot_val = sum(m * pos["qty"] for pos, m in zip(positions, marks)) or 1.0
                for pos, m in zip(positions, marks):
                    g = (pos["entry"] - m) * pos["qty"]
                    gross_book += g
                    realized_net += g
                    row = pos["row"]
                    row["gross"] += g
                    row["exit_cost"] += exit_cost * (m * pos["qty"]) / tot_val
                    row["exit_time"] = now
                    row["exit_reason"] = "Stop-loss"
                    row["open"] = False
                stops.append(dict(time=now, legs=len(positions), premium=premium, loss=loss,
                                  gross=gross_book, exit_cost=exit_cost, spot=S))
                positions = []
                stopped_today = d
                later = [x for x in run_days if x > d]
                resume_date = later[0] if later else d + dt.timedelta(days=1)
                equity_bars.append((now, realized_net))
                continue

            eq = realized_net + unreal
            if is_settlement_bar:
                keep = []
                for pos, m in zip(positions, marks):
                    if pos["expiry"] == d:
                        g = (pos["entry"] - m) * pos["qty"]
                        realized_net += g
                        row = pos["row"]
                        row["gross"] += g
                        row["exit_time"] = now
                        row["exit_reason"] = "Expiry"
                        row["open"] = False
                    else:
                        keep.append(pos)
                positions = keep
                unreal_left = sum((pos["entry"] - mark(pos, S, sig, now)) * pos["qty"] for pos in positions)
                eq = realized_net + unreal_left
            equity_bars.append((now, eq))

    if not entries:
        raise ValueError("No trades were generated for these settings. Try a wider period or a different entry time.")

    # ---- still-open positions at the end ----
    last_t = days[run_days[-1]][-1][0] + dt.timedelta(minutes=5)
    last_b, last_v = days[run_days[-1]][-1][1], days[run_days[-1]][-1][2]
    open_prem = open_mtm = 0.0
    for pos in positions:
        m = mark(pos, last_b["close"], last_v["close"] / 100.0 * ivf, last_t)
        open_mtm += (pos["entry"] - m) * pos["qty"]
        open_prem += pos["entry"] * pos["qty"]

    return _build_result(p, warnings, run_days, entries, stops, equity_bars, margin_snaps,
                         cost_total, open_mtm, open_prem, len(positions))


# ----------------------------------------------------------------------
# Results / metrics
# ----------------------------------------------------------------------
def _build_result(p, warnings, run_days, entries, stops, equity_bars, margin_snaps,
                  cost_total, open_mtm, open_prem, open_legs):
    # ---- daily equity ----
    daily = OrderedDict()
    for now, eq in equity_bars:
        daily[now.date()] = eq
    dates = list(daily)
    values = [daily[k] for k in dates]
    final_equity = values[-1]

    # ---- margin ----
    day_margin = defaultdict(float)
    for t, total, d in margin_snaps:
        day_margin[t.date()] = max(day_margin[t.date()], total)
    peak_margin = max((m for _, m, _ in margin_snaps), default=0.0)
    peak_margin_time = None
    for t, m, _d in margin_snaps:
        if m == peak_margin:
            peak_margin_time = t
    avg_margin = (sum(day_margin[d] for d in dates) / len(dates)) if dates else 0.0
    expiry_day_peak = max((m for t, m, d in margin_snaps
                           if any(e["expiry"] == t.date() for e in entries)), default=0.0)

    capital = p["capital"] or peak_margin
    capital_source = "your input" if p["capital"] else "estimated peak margin"
    if capital <= 0:
        capital = 1.0

    net = final_equity
    years = max((run_days[-1] - run_days[0]).days / 365.25, 1 / 365.25)
    end_value = capital + net
    cagr = (end_value / capital) ** (1.0 / years) - 1.0 if end_value > 0 else -1.0
    roc = net / capital

    # ---- drawdown (end-of-day) ----
    peak = 0.0
    dd_series = []
    mdd = 0.0
    mdd_date = None
    longest_dd_days = 0
    peak_date = dates[0]
    underwater_start = None
    for d, v in zip(dates, values):
        if v >= peak:
            peak = v
            peak_date = d
            if underwater_start is not None:
                longest_dd_days = max(longest_dd_days, (d - underwater_start).days)
                underwater_start = None
        else:
            if underwater_start is None:
                underwater_start = peak_date
        dd = v - peak
        dd_series.append(dd)
        if dd < mdd:
            mdd, mdd_date = dd, d
    if underwater_start is not None:
        longest_dd_days = max(longest_dd_days, (dates[-1] - underwater_start).days)
    currently_in_dd = dd_series[-1] < -1e-9

    # ---- daily return stats (on capital) ----
    rets = []
    prev = 0.0
    for v in values:
        rets.append((v - prev) / capital)
        prev = v
    n = len(rets)
    mean = sum(rets) / n
    var = sum((x - mean) ** 2 for x in rets) / (n - 1) if n > 1 else 0.0
    std = math.sqrt(var)
    downside = math.sqrt(sum(min(x, 0.0) ** 2 for x in rets) / n)
    sharpe = mean / std * math.sqrt(252) if std > 0 else None
    sortino = mean / downside * math.sqrt(252) if downside > 0 else None
    mdd_pct = mdd / capital
    calmar = (cagr / abs(mdd_pct)) if mdd_pct < 0 else None

    # ---- trade stats (closed entries, net of costs) ----
    closed = [e for e in entries if not e["open"]]
    nets = [e["gross"] - e["entry_cost"] - e["exit_cost"] for e in closed]
    wins = [x for x in nets if x > 0]
    losses = [x for x in nets if x <= 0]
    gross_wins = sum(wins)
    gross_losses = -sum(losses)
    profit_factor = (gross_wins / gross_losses) if gross_losses > 0 else None

    # ---- monthly P&L ----
    monthly = []
    prev_eq = 0.0
    cur_key, cur_last = None, 0.0
    for d, v in zip(dates, values):
        key = d.strftime("%Y-%m")
        if cur_key is None:
            cur_key = key
        if key != cur_key:
            monthly.append({"month": cur_key, "pnl": round(cur_last - prev_eq, 2)})
            prev_eq = cur_last
            cur_key = key
        cur_last = v
    monthly.append({"month": cur_key, "pnl": round(cur_last - prev_eq, 2)})

    if years < 0.9:
        warnings.append(
            f"The test covers only {years * 12:.1f} months, so CAGR is an annualised figure from a short window - "
            "treat it with caution."
        )
    if p["structure"] != "strangle":
        warnings.append("Single-leg selling has unlimited-style risk on one side - margin and drawdowns can be large.")

    equity = [
        {"date": d.isoformat(), "equity": round(v, 2), "drawdown": round(dd, 2),
         "margin": round(day_margin.get(d, 0.0), 0)}
        for d, v, dd in zip(dates, values, dd_series)
    ]

    trades = []
    for e in entries:
        net_e = e["gross"] - e["entry_cost"] - e["exit_cost"]
        prem = ((e["call_prem"] or 0) + (e["put_prem"] or 0)) * e["qty"]
        trades.append({
            "id": e["id"], "date": e["date"].isoformat(), "time": e["time"].strftime("%H:%M"),
            "expiry": e["expiry"].isoformat(), "spot": round(e["spot"], 2), "vix": e["vix"],
            "qty": e["qty"],
            "call_strike": e["call_strike"], "put_strike": e["put_strike"],
            "call_delta": None if e["call_delta"] is None else round(e["call_delta"], 3),
            "put_delta": None if e["put_delta"] is None else round(e["put_delta"], 3),
            "premium": round(prem, 2),
            "exit": e["exit_time"].strftime("%Y-%m-%d %H:%M") if e["exit_time"] else None,
            "exit_reason": e["exit_reason"] or "Open",
            "gross": None if e["open"] else round(e["gross"], 2),
            "costs": round(e["entry_cost"] + e["exit_cost"], 2),
            "net": None if e["open"] else round(net_e, 2),
        })

    summary = {
        # headline
        "net_pnl": round(net, 2),
        "gross_pnl": round(net + cost_total, 2),
        "total_costs": round(cost_total, 2),
        "capital": round(capital, 0),
        "capital_source": capital_source,
        "return_on_capital_pct": round(roc * 100, 2),
        "cagr_pct": round(cagr * 100, 2),
        "years": round(years, 3),
        # risk
        "max_drawdown": round(mdd, 2),
        "max_drawdown_pct": round(mdd_pct * 100, 2),
        "max_drawdown_date": mdd_date.isoformat() if mdd_date else None,
        "longest_drawdown_days": longest_dd_days,
        "in_drawdown_now": currently_in_dd,
        "sharpe": None if sharpe is None else round(sharpe, 2),
        "sortino": None if sortino is None else round(sortino, 2),
        "calmar": None if calmar is None else round(calmar, 2),
        # trades
        "entries": len(entries),
        "closed_entries": len(closed),
        "open_entries": len(entries) - len(closed),
        "stop_outs": len(stops),
        "win_rate_pct": round(len(wins) / len(closed) * 100, 1) if closed else None,
        "avg_win": round(gross_wins / len(wins), 2) if wins else None,
        "avg_loss": round(sum(losses) / len(losses), 2) if losses else None,
        "profit_factor": None if profit_factor is None else round(profit_factor, 2),
        "expectancy": round(sum(nets) / len(nets), 2) if nets else None,
        "best_trade": round(max(nets), 2) if nets else None,
        "worst_trade": round(min(nets), 2) if nets else None,
        "avg_premium_per_entry": round(sum(t["premium"] for t in trades) / len(trades), 2),
        # capital / margin
        "peak_margin": round(peak_margin, 0),
        "peak_margin_time": peak_margin_time.strftime("%Y-%m-%d %H:%M") if peak_margin_time else None,
        "expiry_day_peak_margin": round(expiry_day_peak, 0),
        "avg_margin": round(avg_margin, 0),
        "roc_on_avg_margin_pct": round(net / avg_margin * 100, 2) if avg_margin else None,
        "open_position_mtm": round(open_mtm, 2),
        "open_legs": open_legs,
    }

    stops_out = [{
        "time": s["time"].strftime("%Y-%m-%d %H:%M"), "date": s["time"].date().isoformat(),
        "legs": s["legs"], "premium": round(s["premium"], 2), "loss": round(s["loss"], 2),
        "spot": round(s["spot"], 2),
    } for s in stops]

    return {
        "params": {k: (v.isoformat() if isinstance(v, dt.date) else v)
                   for k, v in p.items() if not k.startswith("_")},
        "period": {"start": run_days[0].isoformat(), "end": run_days[-1].isoformat(),
                   "trading_days": len(run_days)},
        "summary": summary,
        "equity": equity,
        "monthly": monthly,
        "stops": stops_out,
        "trades": trades,
        "warnings": warnings,
        "assumptions": ASSUMPTIONS,
    }
