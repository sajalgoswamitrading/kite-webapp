@echo off
title Kite Webapp Launcher
set "ROOT=%~dp0"

echo Starting Kite backend  (http://localhost:8000) ...
start "Kite Backend" /D "%ROOT%backend" cmd /k ".venv\Scripts\python.exe -m uvicorn main:app --reload --port 8000"

echo Starting Kite frontend (http://localhost:5173) ...
start "Kite Frontend" /D "%ROOT%frontend" cmd /k "npm run dev"

echo Waiting for servers to come up...
timeout /t 7 /nobreak >nul
start "" "http://localhost:5173"
exit
