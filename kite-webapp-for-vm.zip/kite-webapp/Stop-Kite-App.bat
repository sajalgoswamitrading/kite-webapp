@echo off
taskkill /FI "WINDOWTITLE eq Kite Backend*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq Kite Frontend*" /T /F >nul 2>&1
echo Kite backend and frontend stopped.
timeout /t 2 >nul
