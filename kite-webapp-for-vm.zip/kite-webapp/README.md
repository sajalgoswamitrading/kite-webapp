# Kite Connect Login (React + Vite + FastAPI)

A minimal login flow for Zerodha Kite Connect: a React/Vite frontend collects
your API Key, API Secret, and a Kite `request_token`; a FastAPI backend
exchanges them for an access token via the official `kiteconnect` SDK and
keeps that token on the server only. The browser never sees it.

## How the token reuse works

`backend/main.py` writes the access token to `backend/kite_session.json`
(git-ignored) after a successful login. Every time the frontend loads, it
calls `GET /api/session`; the backend checks the saved token by calling
`kite.profile()`, and if it's still valid you're sent straight to
`/dashboard` -- no need to log in again after a code change or a page
refresh. Kite access tokens are valid until they're explicitly invalidated
or the exchange resets them (typically in the early morning IST), so you'll
only need to log in again once a day, or if you log out.

## 1. Backend setup

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

The backend now runs at `http://localhost:8000`.

## 2. Frontend setup

In a separate terminal:

```bash
cd frontend
npm install
npm run dev
```

The frontend runs at `http://localhost:5173` (open that in your browser).

## 3. Getting a request_token to log in with

1. Go to `https://developers.kite.trade`, open your app, and copy its
   **API Key** and **API Secret**.
2. On the login page, enter your API Key -- a "log in to Kite here" link
   will appear.
3. Click it, log in with your Zerodha credentials, and approve the app.
   Kite redirects you to your app's registered redirect URL with
   `?request_token=XXXX...` in the address bar.
4. Copy that token value and paste it into the Request Token field, then
   click Login.

Request tokens are single-use and expire within a couple of minutes, so
generate a fresh one right before logging in.

## The dashboard

After login you land on a tabbed dashboard (dark mode). Three tabs ship out
of the box:

- **User** -- calls `GET /api/profile` and shows User Name, User ID,
  Products, and Exchanges.
- **Margins** -- calls `GET /api/margins` and shows the available equity
  balance, as a second working example.
- **Signals** -- a NIFTY 100 SMA crossover scanner. Set Short SMA, Long
  SMA, Lookback Days, and Max Stocks, then click **Generate Signals**. The
  backend (`POST /api/signals/scan`) downloads the official NIFTY 100
  constituent list from NSE, maps each symbol to its Kite instrument
  token, pulls daily candles for each stock, computes the two SMAs, and
  returns the most recent bullish/bearish crossover per stock, ranked
  most-recent-first, in a table with Rank / Ticker / Company / Crossover
  Type / Crossover Date / Close / SMA columns.

  A scan makes one Kite historical-data call per stock (with a small
  delay between each to respect Kite's rate limit), so a full 100-stock
  scan can take a minute or two -- the tab shows a loading message while
  it works. Start with a smaller Max Stocks value (the default is 20) if
  you just want a quick look.

### Adding a new tab

1. Create a component in `frontend/src/tabs/`, e.g. `HoldingsTab.jsx`. It
   can call an existing backend endpoint via `../api.js`, or a new one you
   add to `backend/main.py` (follow the pattern of `/api/profile` --
   fetch via `get_authenticated_kite()`, return JSON, never the token).
2. Register it in `frontend/src/tabs/index.js`:
   ```js
   import HoldingsTab from './HoldingsTab.jsx'
   // ...
   export const DASHBOARD_TABS = [
     { id: 'user', label: 'User', component: UserTab },
     { id: 'margins', label: 'Margins', component: MarginsTab },
     { id: 'signals', label: 'Signals', component: SignalsTab },
     { id: 'holdings', label: 'Holdings', component: HoldingsTab },
   ]
   ```
   That's it -- the tab bar in `Dashboard.jsx` renders whatever is listed
   here, nothing else needs to change.

### Customizing the look

All colors, radii, and shadows live in one place:
`frontend/src/theme.css`. Change `--accent` to re-color buttons and
highlights, or any of the `--bg` / `--surface` / `--text-*` variables to
adjust the dark palette -- every component reads from these variables
rather than hardcoding colors.

### Backtest tab (options selling)

The **Backtest** tab replays a simple options-selling rule on past data: every
trading day at a chosen time, sell NIFTY *monthly* options at a chosen delta
(strangle, put only, or call only), hold to expiry, and close the whole book if
the loss exceeds N x the premium collected (then start fresh the next day).

- **Settings**: strategy, delta (with presets 0.05 - 0.30), lots per day, entry
  time, strike step (50/100), stop-loss multiple (or off), test period. Advanced:
  IV adjustment (multiplier on India VIX) and your own capital.
- **Compare deltas** runs 0.05 - 0.30 with your other settings and lists the
  results side by side; **Open** loads any row.
- **Results**: net P&L, return on capital, CAGR, max drawdown, estimated peak /
  average margin, Sharpe / Sortino / Calmar, win rate, profit factor, expectancy,
  month-by-month P&L, a downloadable trade log, and the **equity curve** (with
  drawdown and stop-loss markers) at the bottom of the tab.

How it works: `POST /api/backtest/run` downloads 5-minute NIFTY 50 and India VIX
candles from Kite (cached in `backend/data_cache/`, so later runs are fast) and
runs `backend/backtest_engine.py`. Real prices of *expired* options are not
available from Kite, so option prices are **modelled** (Black-Scholes, India VIX as
the implied volatility) and margin is **estimated** (SPAN-style). Treat results as
a way to compare settings, not as a forecast. Earliest supported start date is
20 Nov 2024. Your Kite Connect app needs the Historical Data add-on.

## Security notes

- `backend/kite_session.json` holds a live access token capable of placing
  real trades on your account. It's already git-ignored -- don't commit it,
  and don't run this backend anywhere but your own machine during
  development.
- CORS on the backend is locked to `http://localhost:5173` by default; if
  you change the frontend's dev port, update `ALLOWED_ORIGINS` in
  `backend/main.py` to match.
- The API Secret is only ever sent once, at login time, directly to your
  own backend over localhost -- it is not stored anywhere.

## Project structure

```
kite-webapp/
  backend/
    main.py            FastAPI app (login, session check, profile, margins,
                        signals scan, backtest, logout)
    backtest_engine.py options-selling backtest engine (pure Python)
    backtest_data.py   Kite candle download + on-disk cache
    requirements.txt
    kite_session.json  created after first login (git-ignored)
  frontend/
    src/
      pages/Login.jsx      login form
      pages/Dashboard.jsx  navbar + tab bar shell
      tabs/
        index.js           tab registry -- add new tabs here
        UserTab.jsx         User Name / User ID / Products / Exchanges
        MarginsTab.jsx      available equity balance
        SignalsTab.jsx      NIFTY 100 SMA crossover scanner + results table
        BacktestTab.jsx     options-selling backtester (settings, results, equity curve)
      components/Tabs.jsx  generic reusable tab bar
      components/EquityChart.jsx  equity curve + drawdown chart (plain SVG)
      backtest.css / backtestFormat.js  Backtest tab styles and number formatting
      api.js               fetch helpers for talking to the backend
      theme.css            design tokens (colors, radius, shadow) -- edit to re-theme
      index.css            component styles, all reading from theme.css
      App.jsx              routing + startup session check
      main.jsx
    index.html
    vite.config.js
    package.json
```
