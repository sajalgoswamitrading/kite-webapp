import { useState } from 'react'

/**
 * Generic tab bar. Pass an array of { id, label, component } and it
 * handles switching between them -- no dashboard-specific logic here,
 * so it can be reused anywhere a tabbed layout is needed.
 */
export default function Tabs({ tabs, defaultTabId }) {
  const [activeId, setActiveId] = useState(defaultTabId || tabs[0]?.id)
  const activeTab = tabs.find((t) => t.id === activeId) || tabs[0]

  if (!activeTab) return null
  const ActiveComponent = activeTab.component

  return (
    <div>
      <div className="tab-bar" role="tablist">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            role="tab"
            aria-selected={tab.id === activeId}
            className={`tab-button${tab.id === activeId ? ' active' : ''}`}
            onClick={() => setActiveId(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="tab-panel" role="tabpanel">
        <ActiveComponent />
      </div>
    </div>
  )
}
