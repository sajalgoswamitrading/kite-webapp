import { useEffect, useMemo, useRef, useState } from 'react'
import { niceDate, pct, rs, rsAxis, rsSigned } from '../backtestFormat.js'

/**
 * Equity curve + drawdown chart (plain SVG, no chart library).
 *
 *  points: [{ date: 'YYYY-MM-DD', equity, drawdown }]  -- end-of-day, in rupees
 *  stops:  [{ date, ... }]                             -- stop-loss events
 *  capital: number                                     -- for the "% of capital" view
 */

const PAD = { l: 62, r: 16, t: 14, b: 26 }
const MAIN_H = 250
const GAP = 34
const DD_H = 92
const TOTAL_H = PAD.t + MAIN_H + GAP + DD_H + PAD.b

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

function niceTicks(min, max, count = 5) {
  if (min === max) {
    min -= 1
    max += 1
  }
  const span = max - min
  const rough = span / count
  const pow = Math.pow(10, Math.floor(Math.log10(rough)))
  const frac = rough / pow
  const step = (frac <= 1 ? 1 : frac <= 2 ? 2 : frac <= 2.5 ? 2.5 : frac <= 5 ? 5 : 10) * pow
  const start = Math.ceil(min / step) * step
  const ticks = []
  for (let v = start; v <= max + step * 0.001; v += step) ticks.push(Math.abs(v) < step * 1e-9 ? 0 : v)
  return { ticks, lo: Math.min(min, ticks[0] ?? min), hi: Math.max(max, ticks[ticks.length - 1] ?? max) }
}

function monthTicks(t0, t1, width) {
  // Dates are ISO day strings (parsed as UTC), so use UTC maths throughout.
  const first = new Date(t0)
  let y = first.getUTCFullYear()
  let m = first.getUTCMonth()
  if (first.getUTCDate() > 1) m += 1
  if (m > 11) {
    m = 0
    y += 1
  }
  const all = []
  for (;;) {
    const t = Date.UTC(y, m, 1)
    if (t > t1) break
    all.push({ t, label: `${MONTHS[m]} ${String(y).slice(2)}` })
    m += 1
    if (m > 11) {
      m = 0
      y += 1
    }
  }
  const maxLabels = Math.max(3, Math.floor((width - PAD.l - PAD.r) / 62))
  const every = Math.max(1, Math.ceil(all.length / maxLabels))
  return all.filter((_, i) => i % every === 0)
}

export default function EquityChart({ points, stops = [], capital }) {
  const wrapRef = useRef(null)
  const [width, setWidth] = useState(880)
  const [mode, setMode] = useState('rupees') // 'rupees' | 'percent'
  const [hoverIdx, setHoverIdx] = useState(null)

  useEffect(() => {
    const el = wrapRef.current
    if (!el || typeof ResizeObserver === 'undefined') return undefined
    const ro = new ResizeObserver((entries) => {
      const w = entries[0].contentRect.width
      if (w > 0) setWidth(Math.max(320, w))
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  const geo = useMemo(() => {
    if (!points || points.length < 2) return null
    const k = mode === 'percent' && capital ? 100 / capital : 1
    const times = points.map((p) => Date.parse(p.date))
    const eq = points.map((p) => p.equity * k)
    const dd = points.map((p) => p.drawdown * k)
    const t0 = times[0]
    const t1 = times[times.length - 1]
    const innerW = width - PAD.l - PAD.r

    const eqMin = Math.min(0, ...eq)
    const eqMax = Math.max(0, ...eq)
    const pad = (eqMax - eqMin) * 0.06 || 1
    const mainScale = niceTicks(eqMin - (eqMin < 0 ? pad : 0), eqMax + pad, 5)
    const ddMin = Math.min(0, ...dd)
    const ddScale = niceTicks(ddMin * 1.08 || -1, 0, 3)

    const x = (t) => PAD.l + ((t - t0) / (t1 - t0 || 1)) * innerW
    const yMain = (v) => PAD.t + (1 - (v - mainScale.lo) / (mainScale.hi - mainScale.lo || 1)) * MAIN_H
    const ddTop = PAD.t + MAIN_H + GAP
    const yDd = (v) => ddTop + (1 - (v - ddScale.lo) / (ddScale.hi - ddScale.lo || 1)) * DD_H

    const line = eq.map((v, i) => `${i ? 'L' : 'M'}${x(times[i]).toFixed(1)},${yMain(v).toFixed(1)}`).join('')
    const ddLine = dd.map((v, i) => `${i ? 'L' : 'M'}${x(times[i]).toFixed(1)},${yDd(v).toFixed(1)}`).join('')
    const ddArea = `${ddLine}L${x(t1).toFixed(1)},${yDd(0).toFixed(1)}L${x(t0).toFixed(1)},${yDd(0).toFixed(1)}Z`

    const stopMarks = stops
      .map((s) => {
        const idx = points.findIndex((p) => p.date === s.date)
        if (idx < 0) return null
        return { x: x(times[idx]), y: yMain(eq[idx]), idx, date: s.date }
      })
      .filter(Boolean)

    return { k, times, eq, dd, x, yMain, yDd, ddTop, mainScale, ddScale, line, ddLine, ddArea, stopMarks, t0, t1 }
  }, [points, stops, width, mode, capital])

  if (!geo) return <p className="muted">Not enough data to draw an equity curve.</p>

  const fmtY = (v) => (mode === 'percent' ? `${+v.toFixed(2)}%` : rsAxis(v))
  const xTicks = monthTicks(geo.t0, geo.t1, width)

  function onMove(e) {
    const rect = e.currentTarget.getBoundingClientRect()
    const px = ((e.clientX - rect.left) / rect.width) * width
    const t = geo.t0 + ((px - PAD.l) / (width - PAD.l - PAD.r)) * (geo.t1 - geo.t0)
    let lo = 0
    let hi = geo.times.length - 1
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1
      if (geo.times[mid] < t) lo = mid
      else hi = mid
    }
    setHoverIdx(Math.abs(geo.times[lo] - t) <= Math.abs(geo.times[hi] - t) ? lo : hi)
  }

  const hp = hoverIdx !== null ? points[hoverIdx] : null
  const hx = hoverIdx !== null ? geo.x(geo.times[hoverIdx]) : 0
  const stopOnHover = hp ? stops.filter((s) => s.date === hp.date) : []
  const tipLeft = hoverIdx !== null && hx > width * 0.62

  return (
    <div className="bt-chart" ref={wrapRef}>
      <div className="bt-chart-toolbar">
        <div className="bt-legend">
          <span><i className="lg-line" /> Account growth (net of costs)</span>
          {geo.stopMarks.length > 0 && <span><i className="lg-stop" /> Stop-loss triggered</span>}
          <span><i className="lg-dd" /> Drawdown from previous high</span>
        </div>
        {capital ? (
          <div className="bt-segment small" role="group" aria-label="Chart units">
            <button type="button" className={mode === 'rupees' ? 'on' : ''} onClick={() => setMode('rupees')}>₹</button>
            <button type="button" className={mode === 'percent' ? 'on' : ''} onClick={() => setMode('percent')}>% of capital</button>
          </div>
        ) : null}
      </div>

      <svg
        viewBox={`0 0 ${width} ${TOTAL_H}`}
        width="100%"
        height={TOTAL_H}
        role="img"
        aria-label="Equity curve and drawdown of the backtest"
        onMouseMove={onMove}
        onMouseLeave={() => setHoverIdx(null)}
      >
        {/* main panel grid + y labels */}
        {geo.mainScale.ticks.map((v) => (
          <g key={`m${v}`}>
            <line x1={PAD.l} x2={width - PAD.r} y1={geo.yMain(v)} y2={geo.yMain(v)} className={v === 0 ? 'bt-zero' : 'bt-gridline'} />
            <text x={PAD.l - 8} y={geo.yMain(v) + 4} textAnchor="end" className="bt-axis">{fmtY(v)}</text>
          </g>
        ))}
        {/* drawdown panel grid + y labels */}
        {geo.ddScale.ticks.map((v) => (
          <g key={`d${v}`}>
            <line x1={PAD.l} x2={width - PAD.r} y1={geo.yDd(v)} y2={geo.yDd(v)} className={v === 0 ? 'bt-zero' : 'bt-gridline'} />
            <text x={PAD.l - 8} y={geo.yDd(v) + 4} textAnchor="end" className="bt-axis">{fmtY(v)}</text>
          </g>
        ))}
        {/* x labels */}
        {xTicks.map((tk) => (
          <g key={tk.t}>
            <line x1={geo.x(tk.t)} x2={geo.x(tk.t)} y1={geo.ddTop + DD_H} y2={geo.ddTop + DD_H + 4} className="bt-gridline" />
            <text x={geo.x(tk.t)} y={geo.ddTop + DD_H + 18} textAnchor="middle" className="bt-axis">{tk.label}</text>
          </g>
        ))}
        <text x={PAD.l} y={PAD.t - 3} className="bt-panel-title">Account growth</text>
        <text x={PAD.l} y={geo.ddTop - 8} className="bt-panel-title">Drawdown</text>

        {/* stop-loss guide lines */}
        {geo.stopMarks.map((s) => (
          <line key={`sl${s.date}`} x1={s.x} x2={s.x} y1={PAD.t} y2={geo.ddTop + DD_H} className="bt-stopline" />
        ))}

        {/* drawdown */}
        <path d={geo.ddArea} className="bt-dd-area" />
        <path d={geo.ddLine} className="bt-dd-line" />
        {/* equity */}
        <path d={geo.line} className="bt-eq-line" />
        {geo.stopMarks.map((s) => (
          <path key={`sm${s.date}`} d={`M${s.x - 5},${s.y - 9}L${s.x + 5},${s.y - 9}L${s.x},${s.y - 1}Z`} className="bt-stopmark" />
        ))}

        {/* hover crosshair */}
        {hp && (
          <g pointerEvents="none">
            <line x1={hx} x2={hx} y1={PAD.t} y2={geo.ddTop + DD_H} className="bt-cross" />
            <circle cx={hx} cy={geo.yMain(geo.eq[hoverIdx])} r="4.5" className="bt-dot" />
            <circle cx={hx} cy={geo.yDd(geo.dd[hoverIdx])} r="3.5" className="bt-dot dd" />
          </g>
        )}
        <rect x={PAD.l} y={PAD.t} width={width - PAD.l - PAD.r} height={geo.ddTop + DD_H - PAD.t} fill="transparent" />
      </svg>

      {hp && (
        <div
          className="bt-tooltip"
          style={{ left: tipLeft ? undefined : hx + 14, right: tipLeft ? width - hx + 14 : undefined, top: 44 }}
        >
          <div className="tt-date">{niceDate(hp.date)}</div>
          <div className="tt-row"><span>Net P&amp;L</span><b className={hp.equity >= 0 ? 'pos' : 'neg'}>{rsSigned(hp.equity)}</b></div>
          {capital ? <div className="tt-row"><span>Return on capital</span><b>{pct((hp.equity / capital) * 100, 2, true)}</b></div> : null}
          <div className="tt-row"><span>Drawdown</span><b className={hp.drawdown < 0 ? 'neg' : ''}>{rs(hp.drawdown)}</b></div>
          {hp.margin ? <div className="tt-row"><span>Est. margin in use</span><b>{rs(hp.margin)}</b></div> : null}
          {stopOnHover.length > 0 && <div className="tt-stop">Stop-loss closed the whole book</div>}
        </div>
      )}
    </div>
  )
}
