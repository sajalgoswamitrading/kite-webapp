import { useEffect, useState } from 'react'
import { api } from '../api.js'

/**
 * A second example tab, included so the tab bar has more than one entry
 * out of the box. Calls GET /api/margins (backend-proxied) and shows the
 * available equity balance.
 */
export default function MarginsTab() {
  const [margins, setMargins] = useState(null)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api
      .getMargins()
      .then(setMargins)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <p className="loading-row">Loading margins...</p>
  if (error) return <p className="error">{error}</p>
  if (!margins) return null

  const available = margins.equity?.available?.live_balance

  return (
    <div className="panel">
      <h2>Margins</h2>
      <div className="field-grid">
        <div className="field">
          <span className="field-label">Available Equity Balance</span>
          <span className="field-value">
            {typeof available === 'number' ? `₹${available.toLocaleString()}` : 'N/A'}
          </span>
        </div>
      </div>
    </div>
  )
}
