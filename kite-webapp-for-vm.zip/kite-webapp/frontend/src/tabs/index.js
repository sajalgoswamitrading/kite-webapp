import UserTab from './UserTab.jsx'
import MarginsTab from './MarginsTab.jsx'
import SignalsTab from './SignalsTab.jsx'
import BacktestTab from './BacktestTab.jsx'

/**
 * Dashboard tab registry. To add a new tab: create a component in this
 * folder (it can fetch its own data from `../api.js` or call a new
 * backend endpoint) and add one entry here -- nothing else needs to
 * change, the tab bar in Dashboard.jsx renders whatever is listed.
 */
export const DASHBOARD_TABS = [
  { id: 'user', label: 'User', component: UserTab },
  { id: 'margins', label: 'Margins', component: MarginsTab },
  { id: 'signals', label: 'Signals', component: SignalsTab },
  { id: 'backtest', label: 'Backtest', component: BacktestTab },
]
