import { useEffect, useMemo, useRef, useState } from 'react'
import { api } from '../api.js'
import EquityChart from '../components/EquityChart.jsx'
import {
  isoMinusDays,
  isoToday,
  niceDate,
  niceMonth,
  num,
  pct,
  rs,
  rsCompact,
  rsSigned,
} from '../backtestFormat.js'
import '../backtest.css'

// The earliest date the model supports (NIFTY lot size 75 + current fee schedule).
const MIN_START = '2024-11-20'
const DELTA_PRESETS = [0.05, 0.1, 0.15, 0.2, 0.3]
const COMPARE_DELTAS = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3]
const ENTRY_TIMES = [
  '09:20', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00',
  '12:30', '13:00', '13:30', '14:00', '14:30', '15:00',
]
const STRUCTURES = [
  { id: 'strangle', label: 'Strangle', hint: 'Sell a call and a put' },
  { id: 'short_put', label: 'Sell Put', hint: 'Sell a put only' },
  { id: 'short_call', label: 'Sell Call', hint: 'Sell a call only' },
]
const STRUCTURE_TEXT = {
  strangle: 'strangle (one call + one put)',
  short_put: 'put',
  short_call: 'call',
}

function defaultForm() {
  const end = isoToday()
  const start = isoMinusDays(end, 365)
  return {
    structure: 'strangle',
    delta: '0.10',
    lots: '1',
    entry_time: '10:00',
    use_stop: true,
    stop_multiple: '2',
    strike_step: '100',
    start_date: start < MIN_START ? MIN_START : start,
    end_date: end,
    iv_factor: '1',
    capital: '',
  }
}

/** Small "?" bubble with a plain-English explanation (CSS tooltip). */
function Info({ text }) {
  return (
    <span className="bt-info" tabIndex={0} data-tip={text} aria-label={text}>
      ?
    </span>
  )
}

function KpiCard({ label, tip, value, sub, tone }) {
  return (
    <div className="bt-kpi">
      <div className="bt-kpi-label">
        {label} {tip && <Info text={tip} />}
      </div>
      <div className={`bt-kpi-value ${tone || ''}`}>{value}</div>
      {sub && <div className="bt-kpi-sub">{sub}</div>}
    </div>
  )
}

function StatGroup({ title, rows }) {
  return (
    <div className="bt-stat-group">
      <h3>{title}</h3>
      <dl>
        {rows.map((r) => (
          <div className="bt-stat-row" key={r.label}>
            <dt>
              {r.label} {r.tip && <Info text={r.tip} />}
            </dt>
            <dd className={r.tone || ''}>{r.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  )
}

function toneOf(v) {
  if (v === null || v === undefined || Math.abs(v) < 1e-9) return ''
  return v > 0 ? 'pos' : 'neg'
}

function describeSetup(form) {
  const stop = form.use_stop
    ? `close everything if the total loss goes beyond ${form.stop_multiple || '2'}× the premium collected`
    : 'with no stop-loss'
  const lots = Number(form.lots) || 1
  return (
    `Every trading day at ${form.entry_time}, sell ${lots} lot${lots === 1 ? '' : 's'} of the ` +
    `${Number(form.delta || 0).toFixed(2)}-delta ${STRUCTURE_TEXT[form.structure]} on the next monthly NIFTY expiry, ` +
    `hold it until expiry, and ${stop}. Test period: ${niceDate(form.start_date)} to ${niceDate(form.end_date)}.`
  )
}

function buildPayload(form, deltaOverride) {
  return {
    structure: form.structure,
    delta: Number(deltaOverride ?? form.delta),
    lots: Number(form.lots),
    entry_time: form.entry_time,
    stop_multiple: form.use_stop ? Number(form.stop_multiple) : null,
    strike_step: Number(form.strike_step),
    start_date: form.start_date,
    end_date: form.end_date,
    iv_factor: Number(form.iv_factor || 1),
    capital: form.capital === '' ? null : Number(form.capital),
  }
}

function validate(form) {
  const d = Number(form.delta)
  if (!(d >= 0.02 && d <= 0.45)) return 'Delta must be between 0.02 and 0.45 (for example 0.10).'
  const lots = Number(form.lots)
  if (!Number.isInteger(lots) || lots < 1 || lots > 100) return 'Lots per day must be a whole number from 1 to 100.'
  if (form.use_stop) {
    const s = Number(form.stop_multiple)
    if (!(s >= 0.5 && s <= 20)) return 'Stop-loss must be between 0.5× and 20× the premium collected.'
  }
  if (!form.start_date || !form.end_date) return 'Please choose a start and end date.'
  if (form.start_date < MIN_START) return `The earliest supported start date is ${niceDate(MIN_START)}.`
  if (form.end_date <= form.start_date) return 'The end date must be after the start date.'
  const days = (Date.parse(form.end_date) - Date.parse(form.start_date)) / 86400000
  if (days < 30) return 'Please choose a period of at least 30 days.'
  const iv = Number(form.iv_factor || 1)
  if (!(iv >= 0.5 && iv <= 2)) return 'IV adjustment must be between 0.5 and 2.0.'
  if (form.capital !== '' && !(Number(form.capital) > 0)) return 'Capital must be a positive number of rupees.'
  return null
}

function takeaway(res) {
  const s = res.summary
  const dir = s.net_pnl >= 0 ? 'made' : 'lost'
  let t =
    `Over ${niceDate(res.period.start)} – ${niceDate(res.period.end)} this setup ${dir} ${rs(Math.abs(s.net_pnl))} ` +
    `after costs, a ${pct(s.return_on_capital_pct, 2, true)} return on the ${rsCompact(s.capital)} of capital it needed. `
  t += `At its worst it was ${rs(Math.abs(s.max_drawdown))} (${pct(Math.abs(s.max_drawdown_pct), 1)} of capital) below its previous high`
  if (s.stop_outs > 0) t += `, and the stop-loss closed the whole book ${s.stop_outs} time${s.stop_outs === 1 ? '' : 's'}`
  t += '.'
  return t
}

function downloadTradesCsv(res) {
  const head = ['Entry date', 'Entry time', 'Expiry', 'Spot', 'India VIX', 'Qty', 'Call strike', 'Put strike',
    'Call delta', 'Put delta', 'Premium collected (Rs)', 'Exit', 'Result', 'Gross P&L (Rs)', 'Costs (Rs)', 'Net P&L (Rs)']
  const rows = res.trades.map((t) => [
    t.date, t.time, t.expiry, t.spot, t.vix, t.qty, t.call_strike ?? '', t.put_strike ?? '',
    t.call_delta ?? '', t.put_delta ?? '', t.premium, t.exit ?? '', t.exit_reason, t.gross ?? '', t.costs, t.net ?? '',
  ])
  const csv = [head, ...rows].map((r) => r.join(',')).join('\n')
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url
  a.download = `backtest_trades_${res.period.start}_${res.period.end}.csv`
  a.click()
  URL.revokeObjectURL(url)
}

/**
 * Backtest tab -- options selling.
 *
 * Every trading day at a chosen time, sell NIFTY monthly options at a chosen
 * delta (strangle, put only or call only), hold to expiry, and close the
 * whole book if the loss exceeds N x the premium collected. The backend
 * (POST /api/backtest/run) downloads real NIFTY + India VIX candles from
 * Kite and models the option prices, so results are estimates.
 */
export default function BacktestTab() {
  const [form, setForm] = useState(defaultForm)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)
  const [compare, setCompare] = useState(null) // { rows, running, progress }
  const resultsRef = useRef(null)

  const set = (field, value) => setForm((f) => ({ ...f, [field]: value }))
  const setDelta = (d) => set('delta', d.toFixed(2))
  const setRange = (months) => {
    const end = form.end_date
    const start = months === 'max' ? MIN_START : isoMinusDays(end, Math.round(months * 30.4))
    set('start_date', start < MIN_START ? MIN_START : start)
  }

  const summaryText = useMemo(() => describeSetup(form), [form])

  useEffect(() => {
    if (result && resultsRef.current) {
      resultsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }, [result])

  async function runBacktest(overrideForm) {
    const f = overrideForm || form
    const problem = validate(f)
    if (problem) {
      setError(problem)
      return
    }
    setError(null)
    setLoading(true)
    setResult(null)
    try {
      setResult(await api.runBacktest(buildPayload(f)))
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  async function runCompare() {
    const problem = validate(form)
    if (problem) {
      setError(problem)
      return
    }
    setError(null)
    setCompare({ rows: [], running: true, progress: 0 })
    const rows = []
    for (let i = 0; i < COMPARE_DELTAS.length; i += 1) {
      const d = COMPARE_DELTAS[i]
      setCompare({ rows: [...rows], running: true, progress: i })
      try {
        const res = await api.runBacktest(buildPayload(form, d))
        rows.push({ delta: d, summary: res.summary })
      } catch (err) {
        setCompare({ rows, running: false, progress: i, error: err.message })
        return
      }
    }
    setCompare({ rows, running: false, progress: COMPARE_DELTAS.length })
  }

  const s = result?.summary

  return (
    <div className="bt">
      {/* ---------------- Intro ---------------- */}
      <div className="panel">
        <h2>Backtest — Options Selling</h2>
        <p className="bt-lead">
          See how a simple rule would have performed in the past: every trading day, sell NIFTY monthly options at a
          delta you choose, hold them to expiry, and track how your account would have grown.
        </p>
        <details className="bt-help">
          <summary>New to this? What do these words mean?</summary>
          <ul>
            <li><b>Delta</b> – roughly the chance that an option finishes in-the-money (in the buyer's favour). A <b>0.10-delta</b> option is far from the current price (about a 10% chance), so it pays little but rarely hurts. Higher delta = more premium, more risk.</li>
            <li><b>Strangle</b> – selling one call (above the market) and one put (below it). You keep the premium if NIFTY stays between the two strikes.</li>
            <li><b>Premium</b> – the money you receive up-front for selling an option.</li>
            <li><b>Stop-loss</b> – a safety rule: if the total loss on all open positions grows beyond a multiple of the premium collected, everything is closed and the strategy starts fresh the next day.</li>
            <li><b>Margin / capital</b> – money Zerodha blocks in your account to hold the positions. Returns are measured against it.</li>
            <li><b>CAGR</b> – return per year, compounded. <b>Drawdown</b> – how far the account fell from its previous high.</li>
          </ul>
        </details>
        <div className="bt-note info">
          Real prices of expired options are not available from Kite, so option prices are <b>modelled</b> from real NIFTY
          and India VIX data, and margin is <b>estimated</b>. Use results to compare settings, not as a promise of future profit.
        </div>
      </div>

      {/* ---------------- Settings ---------------- */}
      <div className="panel bt-form">
        <h2>Settings</h2>

        <div className="bt-grid">
          <div className="bt-field wide">
            <span className="bt-label">Strategy <Info text="What to sell each day. A strangle sells both a call and a put; the single-leg options sell only one side." /></span>
            <div className="bt-segment" role="group" aria-label="Strategy">
              {STRUCTURES.map((st) => (
                <button
                  type="button"
                  key={st.id}
                  className={form.structure === st.id ? 'on' : ''}
                  onClick={() => set('structure', st.id)}
                  title={st.hint}
                >
                  {st.label}
                </button>
              ))}
            </div>
            <span className="bt-help-text">{STRUCTURES.find((x) => x.id === form.structure).hint}, on the next monthly expiry.</span>
          </div>

          <div className="bt-field wide">
            <label htmlFor="bt-delta" className="bt-label">Delta <Info text="How far from the current price to sell. Lower delta = further away = safer but smaller premium. The nearest strike at or below this delta is used." /></label>
            <div className="bt-delta-row">
              <input
                id="bt-delta"
                type="number"
                min="0.02"
                max="0.45"
                step="0.01"
                value={form.delta}
                onChange={(e) => set('delta', e.target.value)}
              />
              <div className="bt-chips" role="group" aria-label="Delta presets">
                {DELTA_PRESETS.map((d) => (
                  <button
                    type="button"
                    key={d}
                    className={Number(form.delta) === d ? 'on' : ''}
                    onClick={() => setDelta(d)}
                  >
                    {d.toFixed(2)}
                  </button>
                ))}
              </div>
            </div>
            <span className="bt-help-text">Try 0.05 (very safe) to 0.30 (aggressive). 0.10 is a common starting point.</span>
          </div>

          <div className="bt-field">
            <label htmlFor="bt-lots" className="bt-label">Lots per day <Info text="How many lots to sell on each entry. 1 NIFTY lot = 75 units (65 from 30 Dec 2025)." /></label>
            <input id="bt-lots" type="number" min="1" max="100" step="1" value={form.lots} onChange={(e) => set('lots', e.target.value)} />
          </div>

          <div className="bt-field">
            <label htmlFor="bt-time" className="bt-label">Entry time <Info text="The time of day you place the trade (uses the price at that moment)." /></label>
            <select id="bt-time" value={form.entry_time} onChange={(e) => set('entry_time', e.target.value)}>
              {ENTRY_TIMES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div className="bt-field">
            <label htmlFor="bt-step" className="bt-label">Strike step <Info text="Strikes are chosen on this grid: 100 = 24,900, 25,000, 25,100…; 50 allows in-between strikes." /></label>
            <select id="bt-step" value={form.strike_step} onChange={(e) => set('strike_step', e.target.value)}>
              <option value="100">100 points</option>
              <option value="50">50 points</option>
            </select>
          </div>

          <div className="bt-field">
            <span className="bt-label">Stop-loss <Info text="If the loss on all open positions exceeds this multiple of the premium collected, everything is closed and the strategy restarts the next trading day." /></span>
            <div className="bt-stop-row">
              <label className="bt-check">
                <input type="checkbox" checked={form.use_stop} onChange={(e) => set('use_stop', e.target.checked)} />
                <span>On</span>
              </label>
              <div className={`bt-suffix ${form.use_stop ? '' : 'disabled'}`}>
                <input
                  type="number"
                  min="0.5"
                  max="20"
                  step="0.5"
                  value={form.stop_multiple}
                  disabled={!form.use_stop}
                  aria-label="Stop-loss multiple"
                  onChange={(e) => set('stop_multiple', e.target.value)}
                />
                <span>× premium</span>
              </div>
            </div>
          </div>

          <div className="bt-field wide">
            <span className="bt-label">Test period <Info text="Data is available from 20 Nov 2024 (when the current NIFTY lot size began). Longer periods download more data the first time." /></span>
            <div className="bt-period-row">
              <input type="date" min={MIN_START} max={isoToday()} value={form.start_date} onChange={(e) => set('start_date', e.target.value)} aria-label="Start date" />
              <span className="bt-to">to</span>
              <input type="date" min={MIN_START} max={isoToday()} value={form.end_date} onChange={(e) => set('end_date', e.target.value)} aria-label="End date" />
              <div className="bt-chips" role="group" aria-label="Quick periods">
                <button type="button" onClick={() => setRange(6)}>6M</button>
                <button type="button" onClick={() => setRange(12)}>1Y</button>
                <button type="button" onClick={() => setRange('max')}>Max</button>
              </div>
            </div>
          </div>
        </div>

        <details className="bt-advanced">
          <summary>Advanced options</summary>
          <div className="bt-grid">
            <div className="bt-field">
              <label htmlFor="bt-iv" className="bt-label">IV adjustment <Info text="Option prices are modelled using India VIX as volatility. 1.00 uses VIX as is. Above 1 makes options richer (like a fat volatility premium), below 1 cheaper. Useful to see how sensitive results are." /></label>
              <input id="bt-iv" type="number" min="0.5" max="2" step="0.05" value={form.iv_factor} onChange={(e) => set('iv_factor', e.target.value)} />
            </div>
            <div className="bt-field">
              <label htmlFor="bt-cap" className="bt-label">Your capital (₹) <Info text="Leave empty to measure returns against the estimated peak margin the strategy needed. Enter your own amount to see returns on that instead." /></label>
              <input id="bt-cap" type="number" min="0" step="10000" placeholder="Auto (peak margin)" value={form.capital} onChange={(e) => set('capital', e.target.value)} />
            </div>
          </div>
        </details>

        <p className="bt-setup-summary"><b>Your setup:</b> {summaryText}</p>

        <div className="bt-actions">
          <button type="button" onClick={() => runBacktest()} disabled={loading || compare?.running}>
            {loading ? 'Running…' : 'Run backtest'}
          </button>
          <button type="button" className="secondary" onClick={runCompare} disabled={loading || compare?.running}>
            {compare?.running ? `Comparing… (${compare.progress + 1}/${COMPARE_DELTAS.length})` : 'Compare deltas'}
          </button>
          <span className="bt-help-text">“Compare deltas” runs 0.05 – 0.30 with your other settings.</span>
        </div>

        {loading && (
          <p className="loading-row">
            Downloading market data from Kite and running the simulation… the first run for a long period can take up to a
            minute; later runs are much faster.
          </p>
        )}
        {error && <p className="error bt-error">{error}</p>}
      </div>

      {/* ---------------- Delta comparison ---------------- */}
      {compare && (compare.rows.length > 0 || compare.error) && (
        <div className="panel">
          <h2>Delta comparison</h2>
          <p className="muted bt-compare-note">
            Same settings, different delta. Click a row's <b>Open</b> button to load it above and see its full results.
          </p>
          {compare.error && <p className="error">{compare.error}</p>}
          <div className="table-wrapper bt-table">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Delta</th><th>Net P&amp;L</th><th>Return on capital</th><th>CAGR</th>
                  <th>Max drawdown</th><th>Win rate</th><th>Stop-outs</th><th>Est. peak margin</th><th />
                </tr>
              </thead>
              <tbody>
                {compare.rows.map((r) => (
                  <tr key={r.delta} className={Number(form.delta) === r.delta ? 'bt-row-active' : ''}>
                    <td><b>{r.delta.toFixed(2)}</b></td>
                    <td className={`numeric ${toneOf(r.summary.net_pnl)}`}>{rsSigned(r.summary.net_pnl)}</td>
                    <td className={`numeric ${toneOf(r.summary.return_on_capital_pct)}`}>{pct(r.summary.return_on_capital_pct, 2, true)}</td>
                    <td className={`numeric ${toneOf(r.summary.cagr_pct)}`}>{pct(r.summary.cagr_pct, 2, true)}</td>
                    <td className="numeric neg">{pct(r.summary.max_drawdown_pct, 1)}</td>
                    <td className="numeric">{r.summary.win_rate_pct === null ? '—' : `${r.summary.win_rate_pct}%`}</td>
                    <td className="numeric">{r.summary.stop_outs}</td>
                    <td className="numeric">{rsCompact(r.summary.peak_margin)}</td>
                    <td>
                      <button
                        type="button"
                        className="secondary bt-mini"
                        disabled={loading}
                        onClick={() => {
                          const next = { ...form, delta: r.delta.toFixed(2) }
                          setForm(next)
                          runBacktest(next)
                        }}
                      >
                        Open
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ---------------- Results ---------------- */}
      {result && s && (
        <div ref={resultsRef} className="bt-results">
          <div className="panel">
            <h2>Results</h2>
            <p className="bt-takeaway">{takeaway(result)}</p>

            {result.warnings.map((w) => (
              <div className="bt-note warn" key={w}>{w}</div>
            ))}

            <div className="bt-kpis">
              <KpiCard
                label="Net profit / loss"
                tip="Total profit or loss after all costs (brokerage, taxes, exchange fees), including positions still open at the end valued at market."
                value={rsSigned(s.net_pnl)}
                tone={toneOf(s.net_pnl)}
                sub={`after ${rs(s.total_costs)} costs`}
              />
              <KpiCard
                label="Return on capital"
                tip="Net profit divided by the capital the strategy needed. By default, capital = the largest margin it would have needed at any point (an estimate)."
                value={pct(s.return_on_capital_pct, 2, true)}
                tone={toneOf(s.return_on_capital_pct)}
                sub={`on ${rsCompact(s.capital)} (${s.capital_source})`}
              />
              <KpiCard
                label="CAGR"
                tip="Compound annual growth rate: the return on capital scaled to a full year. For tests shorter than a year it is an annualised estimate."
                value={pct(s.cagr_pct, 2, true)}
                tone={toneOf(s.cagr_pct)}
                sub={`over ${num(s.years, 2)} years`}
              />
              <KpiCard
                label="Max drawdown"
                tip="The biggest fall from a previous high in account value (end-of-day). It shows the worst losing stretch you would have had to sit through."
                value={pct(s.max_drawdown_pct, 2)}
                tone="neg"
                sub={`${rs(s.max_drawdown)} on ${niceDate(s.max_drawdown_date)}`}
              />
            </div>

            <div className="bt-stat-groups">
              <StatGroup
                title="Capital & margin"
                rows={[
                  { label: 'Capital used', value: rsCompact(s.capital), tip: 'The money used as the base for return maths: your own capital if you entered one, otherwise the estimated peak margin.' },
                  { label: 'Peak margin (est.)', value: rsCompact(s.peak_margin), tip: 'Highest margin the open positions would have blocked at any moment, from a SPAN-style estimate. Zerodha’s own calculator will differ somewhat.' },
                  { label: 'Peak on an expiry day', value: rsCompact(s.expiry_day_peak_margin), tip: 'Expiry days need extra exposure margin on expiring options, so the peak often falls then.' },
                  { label: 'Average margin (est.)', value: rsCompact(s.avg_margin), tip: 'Average daily margin in use across the test.' },
                  { label: 'Return on average margin', value: pct(s.roc_on_avg_margin_pct, 2, true), tone: toneOf(s.roc_on_avg_margin_pct), tip: 'Net profit divided by the average margin used instead of the peak.' },
                  { label: 'Gross profit (before costs)', value: rsSigned(s.gross_pnl), tone: toneOf(s.gross_pnl) },
                  { label: 'Total costs', value: rs(s.total_costs), tip: 'Brokerage (₹20/order), STT, exchange & SEBI fees, stamp duty and GST.' },
                ]}
              />
              <StatGroup
                title="Risk"
                rows={[
                  { label: 'Max drawdown', value: `${rs(s.max_drawdown)} (${pct(s.max_drawdown_pct, 2)})`, tone: 'neg', tip: 'Largest peak-to-trough fall in account value, in rupees and as a % of capital.' },
                  { label: 'Longest time below a peak', value: `${s.longest_drawdown_days} days${s.in_drawdown_now ? ' (still ongoing)' : ''}`, tip: 'The longest stretch the account stayed under a previous high.' },
                  { label: 'Sharpe ratio', value: num(s.sharpe), tip: 'Return per unit of risk, annualised (ignoring the risk-free rate). Above 1 is good; below 0.5 is weak.' },
                  { label: 'Sortino ratio', value: num(s.sortino), tip: 'Like Sharpe, but only counts down days as risk.' },
                  { label: 'Calmar ratio', value: num(s.calmar), tip: 'CAGR divided by max drawdown %. Higher = more reward for the pain endured.' },
                  { label: 'Stop-loss triggered', value: `${s.stop_outs} time${s.stop_outs === 1 ? '' : 's'}`, tip: 'How often the loss on the whole book crossed the stop-loss level and everything was closed.' },
                ]}
              />
              <StatGroup
                title="Trades"
                rows={[
                  { label: 'Daily entries', value: `${s.entries}${s.open_entries ? ` (${s.open_entries} still open)` : ''}`, tip: 'Number of days a trade was placed. Days right after a stop-loss are skipped.' },
                  { label: 'Win rate', value: s.win_rate_pct === null ? '—' : `${s.win_rate_pct}%`, tip: 'Share of finished trades that made a profit after costs.' },
                  { label: 'Profit factor', value: num(s.profit_factor), tip: 'Total profit from winning trades ÷ total loss from losing trades. Above 1 = profitable; above 1.5 = good.' },
                  { label: 'Average win', value: rs(s.avg_win), tone: 'pos' },
                  { label: 'Average loss', value: rs(s.avg_loss), tone: 'neg' },
                  { label: 'Expectancy per trade', value: rsSigned(s.expectancy), tone: toneOf(s.expectancy), tip: 'Average net profit or loss per finished trade.' },
                  { label: 'Best / worst trade', value: `${rs(s.best_trade)} / ${rs(s.worst_trade)}` },
                  { label: 'Avg premium per entry', value: rs(s.avg_premium_per_entry), tip: 'Average money received up-front per daily entry.' },
                ]}
              />
            </div>

            {result.monthly.length > 0 && (
              <>
                <h3 className="bt-sub">Month by month</h3>
                <div className="bt-months">
                  {result.monthly.map((m) => (
                    <div className={`bt-month ${toneOf(m.pnl)}`} key={m.month} title={`${niceMonth(m.month)}: ${rsSigned(m.pnl)}`}>
                      <span>{niceMonth(m.month)}</span>
                      <b>{rsSigned(m.pnl)}</b>
                    </div>
                  ))}
                </div>
              </>
            )}
            <details className="bt-assumptions">
              <summary>How this backtest works &amp; its limits</summary>
              <ul>
                {result.assumptions.map((a) => <li key={a}>{a}</li>)}
              </ul>
            </details>
          </div>

          {/* ---------------- Trade log ---------------- */}
          <div className="panel">
            <details className="bt-log">
              <summary>Trade log ({result.trades.length} entries)</summary>
              <div className="bt-log-actions">
                <button type="button" className="secondary bt-mini" onClick={() => downloadTradesCsv(result)}>Download CSV</button>
              </div>
              <div className="table-wrapper bt-table bt-log-table">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Entry</th><th>Expiry</th><th>NIFTY</th><th>Call</th><th>Put</th>
                      <th>Premium</th><th>Exit</th><th>Result</th><th>Net P&amp;L</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.trades.map((t) => (
                      <tr key={t.id}>
                        <td>{niceDate(t.date)} {t.time}</td>
                        <td>{niceDate(t.expiry)}</td>
                        <td className="numeric">{t.spot.toFixed(0)}</td>
                        <td className="numeric">{t.call_strike ?? '—'}</td>
                        <td className="numeric">{t.put_strike ?? '—'}</td>
                        <td className="numeric">{rs(t.premium)}</td>
                        <td>{t.exit ? niceDate(t.exit) : '—'}</td>
                        <td>
                          <span className={`signal-badge ${t.exit_reason === 'Stop-loss' ? 'bearish' : t.exit_reason === 'Expiry' ? 'bullish' : 'neutral'}`}>
                            {t.exit_reason}
                          </span>
                        </td>
                        <td className={`numeric ${toneOf(t.net)}`}>{t.net === null ? '—' : rsSigned(t.net)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </details>
          </div>

          {/* ---------------- Equity curve (bottom of the screen) ---------------- */}
          <div className="panel bt-equity-panel">
            <h2>Equity curve</h2>
            <p className="muted bt-equity-note">
              How the account would have grown, net of costs. Open positions are valued at market each day. Hover the chart to
              read any day.
            </p>
            <EquityChart points={result.equity} stops={result.stops} capital={s.capital} />
          </div>
        </div>
      )}
    </div>
  )
}
