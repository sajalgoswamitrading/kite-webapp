import { useEffect, useState } from 'react'
import { api } from '../api.js'

/**
 * Calls GET /api/profile (backend-proxied Kite profile call -- the access
 * token itself never reaches the browser) and displays the fields the
 * dashboard cares about: name, user ID, products, and exchanges.
 */
export default function UserTab() {
  const [profile, setProfile] = useState(null)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api
      .getProfile()
      .then(setProfile)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <p className="loading-row">Loading profile...</p>
  if (error) return <p className="error">{error}</p>
  if (!profile) return null

  return (
    <div className="panel">
      <h2>User</h2>
      <div className="field-grid">
        <div className="field">
          <span className="field-label">User Name</span>
          <span className="field-value">{profile.user_name}</span>
        </div>

        <div className="field">
          <span className="field-label">User ID</span>
          <span className="field-value">{profile.user_id}</span>
        </div>

        <div className="field">
          <span className="field-label">Products</span>
          {profile.products?.length ? (
            <div className="badge-list">
              {profile.products.map((p) => (
                <span className="badge" key={p}>
                  {p}
                </span>
              ))}
            </div>
          ) : (
            <span className="muted">None</span>
          )}
        </div>

        <div className="field">
          <span className="field-label">Exchanges</span>
          {profile.exchanges?.length ? (
            <div className="badge-list">
              {profile.exchanges.map((ex) => (
                <span className="badge" key={ex}>
                  {ex}
                </span>
              ))}
            </div>
          ) : (
            <span className="muted">None</span>
          )}
        </div>
      </div>
    </div>
  )
}
