import { useState } from 'react'
import { api } from '../api.js'

const DEFAULTS = {
  short_sma: 6,
  long_sma: 30,
  lookback_days: 200,
  max_stocks: 20,
}

/**
 * NIFTY 100 SMA crossover scanner. Calls POST /api/signals/scan, which
 * (server-side, using the stored Kite session) downloads the official
 * NIFTY 100 list, maps symbols to instrument tokens, pulls daily candles,
 * computes the two SMAs, and returns the most recent crossover per stock.
 */
export default function SignalsTab() {
  const [form, setForm] = useState(DEFAULTS)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)

  function updateField(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  function validate() {
    if (form.short_sma < 1) return 'Short SMA must be at least 1.'
    if (form.long_sma <= form.short_sma) return 'Long SMA must be greater than Short SMA.'
    if (form.lookback_days < form.long_sma + 5) {
      return `Lookback Days should be at least ${form.long_sma + 5} for a ${form.long_sma}-day SMA.`
    }
    if (form.max_stocks < 1 || form.max_stocks > 100) return 'Max Stocks must be between 1 and 100.'
    return null
  }

  async function handleGenerate() {
    const validationError = validate()
    if (validationError) {
      setError(validationError)
      return
    }

    setError(null)
    setLoading(true)
    setResult(null)
    try {
      const data = await api.scanSignals(form)
      setResult(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="panel">
      <h2>Signals -- NIFTY 100 SMA Crossover Scanner</h2>

      <div className="scan-form">
        <div className="field-inline">
          <label>Short SMA</label>
          <input
            type="number"
            min="1"
            value={form.short_sma}
            onChange={(e) => updateField('short_sma', Number(e.target.value))}
          />
        </div>

        <div className="field-inline">
          <label>Long SMA</label>
          <input
            type="number"
            min="2"
            value={form.long_sma}
            onChange={(e) => updateField('long_sma', Number(e.target.value))}
          />
        </div>

        <div className="field-inline">
          <label>Lookback Days</label>
          <input
            type="number"
            min="30"
            value={form.lookback_days}
            onChange={(e) => updateField('lookback_days', Number(e.target.value))}
          />
        </div>

        <div className="field-inline">
          <label>Max Stocks</label>
          <input
            type="number"
            min="1"
            max="100"
            value={form.max_stocks}
            onChange={(e) => updateField('max_stocks', Number(e.target.value))}
          />
        </div>

        <button onClick={handleGenerate} disabled={loading}>
          {loading ? 'Scanning...' : 'Generate Signals'}
        </button>
      </div>

      {loading && (
        <p className="loading-row">
          Scanning up to {form.max_stocks} stocks from the NIFTY 100 -- this fetches one
          Kite historical-data call per stock, so it can take a minute or two.
        </p>
      )}

      {error && <p className="error">{error}</p>}

      {result && !loading && (
        <>
          <p className="scan-meta">
            Scanned {result.scanned} stock{result.scanned === 1 ? '' : 's'}, found{' '}
            {result.with_signal} with a crossover in the lookback window.
          </p>

          {result.signals.length === 0 ? (
            <p className="muted">No crossovers found. Try a longer Lookback Days window.</p>
          ) : (
            <div className="table-wrapper">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Ticker</th>
                    <th>Company</th>
                    <th>Crossover Type</th>
                    <th>Crossover Date</th>
                    <th>Close</th>
                    <th>SMA {result.short_sma}</th>
                    <th>SMA {result.long_sma}</th>
                  </tr>
                </thead>
                <tbody>
                  {result.signals.map((s) => (
                    <tr key={s.symbol}>
                      <td>{s.rank}</td>
                      <td>{s.symbol}</td>
                      <td>{s.company}</td>
                      <td>
                        <span
                          className={`signal-badge ${
                            s.signal_type === 'Bullish' ? 'bullish' : 'bearish'
                          }`}
                        >
                          {s.signal_type}
                        </span>
                      </td>
                      <td>{s.crossover_date}</td>
                      <td className="numeric">{s.close.toFixed(2)}</td>
                      <td className="numeric">{s.sma_fast.toFixed(2)}</td>
                      <td className="numeric">{s.sma_slow.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  )
}
