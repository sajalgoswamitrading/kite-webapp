// Small fetch helper for talking to the FastAPI backend.
// The Kite access token never passes through here -- the backend keeps it
// and only ever returns plain status/profile data.

const API_BASE = 'http://localhost:8000'

// How long to wait before giving up on a hung request. Most calls are fast
// (local backend, simple JSON) so a short timeout is safe. The one
// exception is the Signals scan, which makes one Kite API call per stock
// and can legitimately take a minute or two -- it gets a much longer
// timeout of its own (see scanSignals below).
const DEFAULT_TIMEOUT_MS = 10_000

async function request(path, options = {}, timeoutMs = DEFAULT_TIMEOUT_MS) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  let res
  try {
    res = await fetch(`${API_BASE}${path}`, {
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      ...options,
    })
  } catch (err) {
    if (err.name === 'AbortError') {
      throw new Error(
        `Could not reach the backend at ${API_BASE} (request timed out after ${Math.round(
          timeoutMs / 1000
        )}s). Make sure the backend server is running.`
      )
    }
    throw new Error(
      `Could not reach the backend at ${API_BASE}. Make sure the backend server is running.`
    )
  } finally {
    clearTimeout(timer)
  }

  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    throw new Error(data.detail || `Request failed: ${res.status}`)
  }
  return data
}

export const api = {
  getSession: () => request('/api/session'),
  login: (payload) =>
    request('/api/login', { method: 'POST', body: JSON.stringify(payload) }),
  getProfile: () => request('/api/profile'),
  getMargins: () => request('/api/margins'),
  logout: () => request('/api/logout', { method: 'POST' }),
  // A scan can take a while (one Kite API call per stock, roughly one
  // every third of a second), so it gets a generous 3-minute timeout
  // instead of the default.
  scanSignals: (payload) =>
    request(
      '/api/signals/scan',
      { method: 'POST', body: JSON.stringify(payload) },
      180_000
    ),
  // A backtest downloads NIFTY + India VIX candles from Kite the first time a
  // period is used (several API calls) and then runs the simulation, so it
  // also gets a long timeout (10 minutes).
  runBacktest: (payload) =>
    request(
      '/api/backtest/run',
      { method: 'POST', body: JSON.stringify(payload) },
      600_000
    ),
}
