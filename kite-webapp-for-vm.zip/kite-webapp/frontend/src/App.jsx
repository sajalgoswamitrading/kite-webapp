import { useEffect, useState } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import { api } from './api.js'

export default function App() {
  const [checking, setChecking] = useState(true)
  const [loggedIn, setLoggedIn] = useState(false)
  const [userName, setUserName] = useState(null)

  // On every app load (including after a code change / page refresh during
  // dev), ask the backend whether it already has a valid saved Kite
  // session. If so, we skip the login page entirely.
  useEffect(() => {
    api
      .getSession()
      .then((data) => {
        setLoggedIn(data.logged_in)
        setUserName(data.user_name || null)
      })
      .catch(() => setLoggedIn(false))
      .finally(() => setChecking(false))
  }, [])

  if (checking) {
    return <div className="centered">Checking for a saved Kite session...</div>
  }

  return (
    <Routes>
      <Route
        path="/"
        element={
          loggedIn ? (
            <Navigate to="/dashboard" replace />
          ) : (
            <Login
              onLoggedIn={(name) => {
                setLoggedIn(true)
                setUserName(name)
              }}
            />
          )
        }
      />
      <Route
        path="/dashboard"
        element={
          loggedIn ? (
            <Dashboard userName={userName} onLoggedOut={() => setLoggedIn(false)} />
          ) : (
            <Navigate to="/" replace />
          )
        }
      />
    </Routes>
  )
}
