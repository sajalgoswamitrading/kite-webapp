import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api.js'

export default function Login({ onLoggedIn }) {
  const [apiKey, setApiKey] = useState('')
  const [apiSecret, setApiSecret] = useState('')
  const [requestToken, setRequestToken] = useState('')
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  async function handleSubmit(e) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      // api_key/api_secret/request_token go straight to the backend, which
      // exchanges them for an access token via the Kite SDK and stores it
      // server-side. The response below never contains the access token.
      const data = await api.login({
        api_key: apiKey,
        api_secret: apiSecret,
        request_token: requestToken,
      })
      onLoggedIn(data.user_name || null)
      navigate('/dashboard')
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const loginUrl = apiKey
    ? `https://kite.trade/connect/login?api_key=${encodeURIComponent(apiKey)}&v=3`
    : null

  return (
    <div className="centered">
      <form className="card" onSubmit={handleSubmit}>
        <h1>Kite Connect Login</h1>

        <label>
          API Key
          <input
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            autoComplete="off"
            required
          />
        </label>

        <label>
          API Secret
          <input
            type="password"
            value={apiSecret}
            onChange={(e) => setApiSecret(e.target.value)}
            autoComplete="off"
            required
          />
        </label>

        <label>
          Request Token
          <input
            value={requestToken}
            onChange={(e) => setRequestToken(e.target.value)}
            autoComplete="off"
            required
          />
        </label>

        {loginUrl && (
          <p className="hint">
            Need a request token? Enter your API key above, then{' '}
            <a href={loginUrl} target="_blank" rel="noreferrer">
              log in to Kite here
            </a>
            . After you approve, copy the <code>request_token</code> value from
            the address bar you get redirected to and paste it above.
          </p>
        )}

        {error && <p className="error">{error}</p>}

        <button type="submit" className="full-width" disabled={loading}>
          {loading ? 'Logging in...' : 'Login'}
        </button>
      </form>
    </div>
  )
}
