import { useNavigate } from 'react-router-dom'
import Tabs from '../components/Tabs.jsx'
import { DASHBOARD_TABS } from '../tabs/index.js'
import { api } from '../api.js'

export default function Dashboard({ userName, onLoggedOut }) {
  const navigate = useNavigate()

  async function handleLogout() {
    await api.logout()
    onLoggedOut()
    navigate('/')
  }

  return (
    <div className="app-shell">
      <nav className="navbar">
        <div className="brand">
          <span className="dot" />
          Kite Dashboard
        </div>
        <div className="user-info">
          <span>{userName ? `Signed in as ${userName}` : 'Signed in'}</span>
          <button className="secondary" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </nav>

      <div className="dashboard-body">
        <Tabs tabs={DASHBOARD_TABS} defaultTabId="user" />
      </div>
    </div>
  )
}
