// Small formatting helpers shared by the Backtest tab and its chart.

const inr = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 })

/** ₹1,23,456 (with a real minus sign for negatives). */
export function rs(v) {
  if (v === null || v === undefined || Number.isNaN(v)) return '—'
  const r = Math.round(v)
  return `${r < 0 ? '−' : ''}₹${inr.format(Math.abs(r))}`
}

/** +₹1,234 / −₹1,234 */
export function rsSigned(v) {
  if (v === null || v === undefined || Number.isNaN(v)) return '—'
  const r = Math.round(v)
  return `${r > 0 ? '+' : r < 0 ? '−' : ''}₹${inr.format(Math.abs(r))}`
}

/** ₹6.74 L / ₹1.20 Cr -- for big rupee amounts (lakh / crore). */
export function rsCompact(v) {
  if (v === null || v === undefined || Number.isNaN(v)) return '—'
  const a = Math.abs(v)
  const sign = v < 0 ? '−' : ''
  if (a >= 1e7) return `${sign}₹${(a / 1e7).toFixed(2)} Cr`
  if (a >= 1e5) return `${sign}₹${(a / 1e5).toFixed(2)} L`
  return `${sign}₹${inr.format(Math.round(a))}`
}

/** Short axis label: ₹2L, −₹50K, 0 */
export function rsAxis(v) {
  if (v === 0) return '0'
  const a = Math.abs(v)
  const sign = v < 0 ? '−' : ''
  if (a >= 1e7) return `${sign}₹${+(a / 1e7).toFixed(2)}Cr`
  if (a >= 1e5) return `${sign}₹${+(a / 1e5).toFixed(2)}L`
  if (a >= 1e3) return `${sign}₹${+(a / 1e3).toFixed(1)}K`
  return `${sign}₹${Math.round(a)}`
}

export function pct(v, digits = 2, signed = false) {
  if (v === null || v === undefined || Number.isNaN(v)) return '—'
  const s = signed && v > 0 ? '+' : v < 0 ? '−' : ''
  return `${s}${Math.abs(v).toFixed(digits)}%`
}

export function num(v, digits = 2) {
  if (v === null || v === undefined || Number.isNaN(v)) return '—'
  return v.toFixed(digits)
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

/** '2025-09-23' -> '23 Sep 2025' */
export function niceDate(iso) {
  if (!iso) return '—'
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number)
  return `${d} ${MONTHS[m - 1]} ${y}`
}

/** '2025-09' -> 'Sep 25' */
export function niceMonth(ym) {
  const [y, m] = ym.split('-').map(Number)
  return `${MONTHS[m - 1]} ${String(y).slice(2)}`
}

export function isoToday() {
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

export function isoMinusDays(iso, days) {
  const [y, m, d] = iso.split('-').map(Number)
  const dt = new Date(y, m - 1, d)
  dt.setDate(dt.getDate() - days)
  const p = (n) => String(n).padStart(2, '0')
  return `${dt.getFullYear()}-${p(dt.getMonth() + 1)}-${p(dt.getDate())}`
}
